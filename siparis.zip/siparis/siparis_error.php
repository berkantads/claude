<!DOCTYPE html>
<html>
<head>
    <title>Sipariş Oluşturuldu</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <?php
    if ($site["site_fb_piksel"]):
        ?>
        <!-- Facebook Pixel Code -->
        <script>
            !function (f, b, e, v, n, t, s) {
                if (f.fbq) return;
                n = f.fbq = function () {
                    n.callMethod ?
                        n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                };
                if (!f._fbq) f._fbq = n;
                n.push = n;
                n.loaded = !0;
                n.version = '2.0';
                n.queue = [];
                t = b.createElement(e);
                t.async = !0;
                t.src = v;
                s = b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t, s)
            }(window, document, 'script',
                'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '<?=$site["site_fb_piksel"];?>');
            fbq('track', 'Purchase', {
                value: '<?=$insertSiparis["sp_siparis_tutari"];?>',
                currency: 'TRY'
            });
            fbq('track', 'PageView');
        </script>
        <noscript>
            <img height="1" width="1"
                 src="https://www.facebook.com/tr?id=<?= $site["site_fb_piksel"]; ?>&ev=PageView&noscript=1"/>
        </noscript>
        <!-- End Facebook Pixel Code -->
    <?php
    endif;
    ?>
</head>
<style>
    @media screen {
        .cerceve {
            position: relative;
            bottom: 20% !important;
        }

        .cerceve > img {
            width: 100%;
        }
    }
</style>
<body>
<div class="container">
	<div class="row text-center">
        <div class="col-sm-6 col-sm-offset-3">
        <br><br> <h2 style="color:#d63031">Siparişiniz Oluşturulmadı</h2>
        <img src="img/error.png" width="150px">
        <p style="font-size:20px;color:#5C5C5C;">
			Siparişiniz sistem tarafından engellenmiştir.
		</p>
    <br><br>
        </div>
        
	</div>
</div>
</body>
</html>