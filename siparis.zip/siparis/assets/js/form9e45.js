function getDistricts(){
    var url = 'ajax.php?type=districts';
    var city = $('select[name="city"]').val();
    $.post(url,{cityid:city}).done(function(data){
        $('select[name="district"]').html(data);
    });
}

function tst(){
    try{
        if($('select[name="options"]').val().length){
        var options = $('select[name="options"]').val();
        var options_name = $('select[name="options"]').prop('id');
        var option = {
            'name':options_name,
            'value':options
        };
        var optionJson = JSON.stringify(option);
        }else{
            var optionJson = '';
        }
    }catch(err){
		var optionJson = '';
    }
    var plength = $('input[name="phone"]').val().length;
    if(plength >= 9){
    var url = 'ajax.php?type=tst';
    var token = $('meta[name="csrf-token"]').attr('content');
    var product_id = $('input[name="product_id"]').val();
    var name = $('input[name="name"]').val();
    var phone = $('input[name="phone"]').val();
    var city = $('select[name="city"]').val();
    var payment_type = $('select[name="payment_type"]').val();
    var district = $('select[name="district"]').val();
    var address = $('textarea[name="address"]').val();
    var product_box = $('input[name="product_box"]:checked').val();
    $.post(url, {product_id:product_id,name:name,phone:phone,city:city,payment_type:payment_type,district:district,address:address,product_box:product_box,product_id: product_id,optionJson:optionJson}).done(function (data) {
        console.log(data);
    });
    }
}
function siparisOlustur(){
	try{
        if($('select[name="options"]').val().length){
        var options = $('select[name="options"]').val();
        var options_name = $('select[name="options"]').prop('id');
        var option = {
            'name':options_name,
            'value':options
        };
        var optionJson = JSON.stringify(option);
        }else{
            var optionJson = '';
        }
    }catch(err){
		var optionJson = '';
    }
    if($('input[name="name"]').val().length < 2){
        $('html, body').animate({
            scrollTop: $('input[name="name"]').offset().top
        }, 1000, function() {
            $('input[name="name"]').focus();
            $('input[name="name"]').css('border','1px solid red');
			$('label#name').show('fast');
        });
    }else if($('input[name="phone"]').val().length < 9){
        $('html, body').animate({
            scrollTop: $('input[name="phone"]').offset().top
        }, 1000, function() {
            $('input[name="phone"]').focus();
            $('input[name="phone"]').css('border','1px solid red');
			$('label#phone').show('fast');
        });
    }else if($('select[name="city"]').val() == 0){
        $('html, body').animate({
            scrollTop: $('select[name="city"]').offset().top
        }, 1000, function() {
            $('select[name="city"]').focus();
            $('select[name="city"]').css('border','1px solid red');
			$('label#city').show('fast');
        });
    }else if($('select[name="district"]').val() == 0){
        $('html, body').animate({
            scrollTop: $('select[name="district"]').offset().top
        }, 1000, function() {
            $('select[name="district"]').focus();
            $('select[name="district"]').css('border','1px solid red');
        });
    }else if($('textarea[name="address"]').val() == 0){
        $('html, body').animate({
            scrollTop: $('textarea[name="address"]').offset().top
        }, 1000, function() {
            $('textarea[name="address"]').focus();
            $('textarea[name="address"]').css('border','1px solid red');
			$('label#address').show('fast');
        });
    }else if($('select[name="payment_type"]').val() == 0){
        $('html, body').animate({
            scrollTop: $('select[name="payment_type"]').offset().top
        }, 1000, function() {
            $('select[name="payment_type"]').focus();
            $('select[name="payment_type"]').css('border','1px solid red');
			$('label#payment_type').show('fast');
        });
    }else{
		$('.error_label').hide();
    var url = 'ajax.php?type=complete';
    var token = $('meta[name="csrf-token"]').attr('content');
    var product_id = $('input[name="product_id"]').val();
    var name = $('input[name="name"]').val();
    var phone = $('input[name="phone"]').val();
    var city = $('select[name="city"]').val();
    var payment_type = $('select[name="payment_type"]').val();
    var district = $('select[name="district"]').val();
    var address = $('textarea[name="address"]').val();
    var product_box = $('input[name="product_box"]:checked').val();
    $('button[name="form_btn"]').prop('disabled','disabled');
    $('button[name="form_btn"]').html('LÜTFEN BEKLEYİN. SİPARİŞİNİZ OLUŞTURULUYOR...');
    $.post(url, {product_id:product_id,name:name,phone:phone,city:city,payment_type:payment_type,district:district,address:address,product_box:product_box,optionJson:optionJson,_token: token}).done(function (data) {
		window.location.href = 'tamamlandi.php';
    });
}
}
function changebox(){
	tst();
	$('html,body').animate({
        scrollTop: $("#contact").offset().top
    }, 'slow');
	$('input[name="name"]').focus();
	$('input[name="name"]').css('border','1px solid #00b894');
}