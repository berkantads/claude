-- Veritabanı güncellemeleri - Yeni ödeme sistemi için
-- Bu SQL dosyasını veritabanınızda çalıştırın

-- siparisler tablosuna yeni alanlar ekle
ALTER TABLE `siparisler` 
ADD COLUMN `sp_payment_method` VARCHAR(50) NULL COMMENT 'Gerçek ödeme yöntemi (stripe, paypal, bank_transfer)' AFTER `sp_odeme_yontemi`,
ADD COLUMN `sp_payment_status` VARCHAR(20) DEFAULT 'pending' COMMENT 'Ödeme durumu (pending, completed, failed, cancelled)' AFTER `sp_payment_method`,
ADD COLUMN `sp_payment_reference` VARCHAR(255) NULL COMMENT 'Ödeme referans numarası (Stripe charge ID, PayPal transaction ID, vb.)' AFTER `sp_payment_status`,
ADD COLUMN `sp_created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Kayıt oluşturma zamanı' AFTER `sp_payment_reference`,
ADD COLUMN `sp_updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Son güncelleme zamanı' AFTER `sp_created_at`;

-- Ödeme durumları için index
CREATE INDEX `idx_payment_status` ON `siparisler` (`sp_payment_status`);
CREATE INDEX `idx_payment_method` ON `siparisler` (`sp_payment_method`);
CREATE INDEX `idx_payment_reference` ON `siparisler` (`sp_payment_reference`);

-- Ödeme günlükleri tablosu (opsiyonel - ödeme işlemlerini izlemek için)
CREATE TABLE IF NOT EXISTS `payment_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `siparis_id` INT NOT NULL,
  `payment_method` VARCHAR(50) NOT NULL,
  `action` VARCHAR(50) NOT NULL COMMENT 'create, success, fail, refund, etc.',
  `amount` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(3) DEFAULT 'EUR',
  `reference_id` VARCHAR(255) NULL,
  `request_data` TEXT NULL COMMENT 'Gönderilen istek verisi (JSON)',
  `response_data` TEXT NULL COMMENT 'Alınan yanıt verisi (JSON)',
  `error_message` TEXT NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_siparis_id` (`siparis_id`),
  INDEX `idx_payment_method` (`payment_method`),
  INDEX `idx_action` (`action`),
  INDEX `idx_created_at` (`created_at`),
  FOREIGN KEY (`siparis_id`) REFERENCES `siparisler`(`sp_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Stripe ödeme detayları tablosu (opsiyonel)
CREATE TABLE IF NOT EXISTS `stripe_payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `siparis_id` INT NOT NULL,
  `stripe_charge_id` VARCHAR(255) NOT NULL,
  `stripe_payment_intent_id` VARCHAR(255) NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(3) DEFAULT 'EUR',
  `status` VARCHAR(50) NOT NULL,
  `card_last4` VARCHAR(4) NULL,
  `card_brand` VARCHAR(20) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_charge` (`stripe_charge_id`),
  INDEX `idx_siparis_id` (`siparis_id`),
  INDEX `idx_status` (`status`),
  FOREIGN KEY (`siparis_id`) REFERENCES `siparisler`(`sp_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- PayPal ödeme detayları tablosu (opsiyonel)
CREATE TABLE IF NOT EXISTS `paypal_payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `siparis_id` INT NOT NULL,
  `paypal_order_id` VARCHAR(255) NOT NULL,
  `paypal_payment_id` VARCHAR(255) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `currency` VARCHAR(3) DEFAULT 'EUR',
  `status` VARCHAR(50) NOT NULL,
  `payer_email` VARCHAR(255) NULL,
  `payer_id` VARCHAR(50) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_payment` (`paypal_payment_id`),
  INDEX `idx_siparis_id` (`siparis_id`),
  INDEX `idx_order_id` (`paypal_order_id`),
  INDEX `idx_status` (`status`),
  FOREIGN KEY (`siparis_id`) REFERENCES `siparisler`(`sp_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mevcut siparişleri güncelle (eski ödeme yöntemi verilerini yeni formata uyarla)
UPDATE `siparisler` 
SET `sp_payment_method` = 'legacy',
    `sp_payment_status` = CASE 
        WHEN `sp_siparis_durumu` = 1 THEN 'completed'
        WHEN `sp_siparis_durumu` = 0 THEN 'pending'
        ELSE 'pending'
    END
WHERE `sp_payment_method` IS NULL;

-- Yedek alma komutu (çalıştırmadan önce)
-- mysqldump -u username -p database_name siparisler > siparisler_backup_$(date +%Y%m%d_%H%M%S).sql 