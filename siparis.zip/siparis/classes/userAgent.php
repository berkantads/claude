<?php

function getAgent()
{
    global $site;
    $userAgent = $_SERVER["HTTP_USER_AGENT"];
    //$userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Instagram 167.0.0.18.114 (iPhone12,5; iOS 14_2; tr_TR; tr-TR; scale=3.00; 1242x2688; 257196069)";
    $fb = strpos($userAgent, "FB_IAB");
	if(!$fb)
		$fb = strpos($userAgent, "FBAN");
    $insta = strpos($userAgent, "Instagram");
    // Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Instagram 167.0.0.18.114 (iPhone12,5; iOS 14_2; tr_TR; tr-TR; scale=3.00; 1242x2688; 257196069)
    // Mozilla/5.0 (Linux; Android 10; POT-LX1 Build/HUAWEIPOT-L21; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.198 Mobile Safari/537.36 Instagram 167.0.0.24.120 Android (29/10; 480dpi; 1080x2139; HUAWEI; POT-LX1; HWPOT-H; kirin710; tr_TR; 256966628)
    // Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 Instagram 167.0.0.18.114 (iPhone9,3; iOS 14_2; tr_TR; tr-TR; scale=2.00; 750x1334; 257196069)
    // Mozilla/5.0 (Linux; Android 10; SM-A715F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.198 Mobile Safari/537.36 Instagram 167.1.0.25.120 Android (29/10; 420dpi; 1080x2183; samsung; SM-A715F; a71; qcom; tr_TR; 259829115)

    // Mozilla/5.0 (Linux; Android 7.0; VIA_P2 Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.66 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/297.0.0.36.116;]
    // Mozilla/5.0 (Linux; Android 10; SM-A750F Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/86.0.4240.110 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/297.0.0.36.116;]
    if ($fb)
        $kaynak = 1;
    elseif ($insta)
        $kaynak = 4;
    else
        $kaynak = $site["site_kaynak"];

    return $kaynak;
}

?>