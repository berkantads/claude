function HarfKontrol(e) {
    olay = document.all ? window.event : e;
    tus = document.all ? olay.keyCode : olay.which;
    if (tus >= 48 && tus <= 57) {
        if (document.all) {
            olay.returnValue = false;
        } else {
            olay.preventDefault();
        }
    }
}


$( "#cardNumber" ).keyup(function(event) {
    var kart_bin = $('input[id="cardNumber"]').val();
    var kart_bin_length = $('input[id="cardNumber"]').val().length;
    if(kart_bin_length == 6)
    {
        $.post('https://odeme.istanbulstok.com/binSorgula.php',{kart_bin}).done(function(data){
            var jsonData = $.parseJSON(data);
            if(jsonData.status == 'success')
            {
                $('input[name="brand"]').val(jsonData.brand);
                if(jsonData.schema == 'MASTERCARD')
                {
                    $('#cardNumber').css("background-image","url('../../../resources/mastercard.png')");
                }else if(jsonData.schema == 'VISA'){
                    $('#cardNumber').css("background-image","url('../../../resources/visa.png')");
                }else if(jsonData.schema == 'TROY'){
                    $('#cardNumber').css("background-image","url('../../../resources/troy.png')");
                }else{
                    $('#cardNumber').css("background-image","url('../../../resources/blank.png')");
                }
            }else{
                $('#cardNumber').css("background-image","url('../../../resources/blank.png')");
            }
        });
    }
  });