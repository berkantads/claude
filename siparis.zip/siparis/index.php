t<?php
require "ayarlar.php";
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title><?= $urun["urun_baslik"]; ?> - Sipariş Formu</title>

<!-- Font Awesome CDN for reliable icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" crossorigin="anonymous">

<!-- TikTok Pixel Code Start -->
<script>
!function (w, d, t) {
  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie","holdConsent","revokeConsent","grantConsent"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(
var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var r="https://analytics.tiktok.com/i18n/pixel/events.js",o=n&&n.partner;ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=r,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};n=document.createElement("script")
;n.type="text/javascript",n.async=!0,n.src=r+"?sdkid="+e+"&lib="+t;e=document.getElementsByTagName("script")[0];e.parentNode.insertBefore(n,e)};


  ttq.load('D1V0QEBC77U2447SGRJ0');
  ttq.page();
}(window, document, 'ttq');
</script>
<!-- TikTok Pixel Code End -->

<link rel="stylesheet" href="css/style.css?v=1.2.0">
<link rel="stylesheet" href="css/payment-module.css?v=1.5.0">

<script>
function SayiKontrol(e) {
	olay = document.all ? window.event : e;
	tus = document.all ? olay.keyCode : olay.which;
	if(tus<48||tus>57) {
		if(document.all) { olay.returnValue = false; } else { olay.preventDefault(); }
	}
}

function HarfKontrol(e) {
	olay = document.all ? window.event : e;
	tus = document.all ? olay.keyCode : olay.which;
	if(tus>=48&&tus<=57) {
		if(document.all) { olay.returnValue = false; } else { olay.preventDefault(); }
	}
}
</script>

</head>

<body>

<header>
<div class="container">
<ol class="nav justify-content-between align-items-center">
<li class="l">



</li>

</ol>
</div>
</header>
<main class="checkout">
<div class="sumbar">
<div class="container">
<ul class="nav justify-content-startXXX align-items-center">
<li><?= $urun["urun_baslik"]; ?> Sipariş Formu</li>
<li class="i-ar"><i class="fas fa-list-alt"></i> Sipariş Özeti</li>
<li class="ml-auto"><a href="../index.html">Geri</a></li>
</ul>
</div>
</div>
<div class="container">
<div class="custom-form"></div>



<form id="siparisformu" class="needs-validation" name="" action="tamamla.php" method="post">

	<div class="col-md-12 form-group">
                <input class="form-control form_textinput" name="product_id" value="9454" style="display:none;"/>
            </div>

<div class="row">
<div class="col-sm-12 col-md-6 col-lg-5 offset-lg-1 col-xl-4 offset-xl-1 order-md-last spack">
<input type="text" class="d-none product-id" name="amount" value="1">
<div class="product">
<p><i class="fas fa-box"></i> Lütfen Paketinizi Seçiniz <i class="fas fa-chevron-down"></i></p>


<div class="form-group">

 <!-- Ürün paketi -->
            <?php
            if ($paketler):
                for ($i = 0;
                     $i < count($paketler);
                     $i++):
                    ?>
                    <input type="radio" class="d-none checkvalid" name="paket" id="product_box_<?= $i; ?>" value="<?= $i; ?>" 
                           data-price="<?= $paketler[$i]->urun_fiyat; ?>" 
                           data-old-price="<?= $paketler[$i]->urun_eski_fiyat ?? ''; ?>"
                           data-cargo="<?= $paketler[$i]->ucretsiz_kargo == 1 ? 0 : $paketler[$i]->kargo_tutari; ?>"
                           data-title="<?= htmlspecialchars($paketler[$i]->baslik); ?>"
                           <?= ($i == 0) ? 'checked=""' : ''; ?>>


<label for="product_box_<?= $i; ?>" class="user-select-none">
<i></i>
<img src="img/pack1.png" alt="<?= htmlspecialchars($paketler[$i]->baslik); ?>">
<span>
<strong><?= $paketler[$i]->baslik; ?></strong>
<small><?= ((!empty($paketler[$i]->icerik))) ? "<span class='baslik'><b>{$paketler[$i]->icerik}</b></span>" : ""; ?></small>
<small><b>%100 Orjinal Garantili</b></small>
<?= (!empty($paketler[$i]->urun_eski_fiyat)) ? "<s class='oldprice'>{$paketler[$i]->urun_eski_fiyat} €</s>" : ""; ?>

<?= (!empty($paketler[$i]->urun_fiyat)) ? "<b class='newprice'>{$paketler[$i]->urun_fiyat} €</b>" : ""; ?><br>

<?=($paketler[$i]->ucretsiz_kargo == 1) ? '<sub class="kargo" style="color:#27ae60;"><i class="fas fa-shipping-fast"></i> ÜCRETSİZ KARGO</sub>' : '<sub class="kargo" style="color:#e74c3c;"><i class="fas fa-truck"></i> '.$paketler[$i]->kargo_tutari.' € KARGO ÜCRETİ</sub>'; ?>
</span>

</label>
<?php
endfor;
endif;
?>
</div>





</div>
</div>
<div class="col-sm-12 col-md-6 col-lg-5 col-xl-5 order-md-first sform">
<div class="address">
<p><i class="fas fa-shipping-fast"></i> Lütfen Teslimat Bilgilerinizi Giriniz <i class="fas fa-chevron-down"></i></p>
<div class="form-group">
<fieldset>
<i class="fas fa-user"></i>
<input type="text" id="adsoyad" name="musteri" onkeypress="HarfKontrol(event)" class="form-control cusem checkvalid" placeholder="Adınız, Soyadınız" required/>
</fieldset>
<abbr class="invalid-feedback">ad ve soyad yazınız</abbr>
</div>
<div class="form-group">
<fieldset>
<i class="fas fa-phone"></i>
<input type="tel" id="telefon" name="telefon"  onkeypress="SayiKontrol(event)" class="form-control cusem checkvalid" placeholder="Cep Telefon Numaranız" required/>
</fieldset>
<abbr class="invalid-feedback">Telefon Numaranız- örn: +449050003920</abbr>
</div>






<div class="form-group">
<textarea placeholder="Adres Bilgileriniz" class="custom-select" name="adres" id="adres" style="height: 100px;"></textarea>
</div>


<!-- varyasyonlar -->
            <?php
            if ($varyasyonlar):
                echo "<div id='varyasyonlar'>";
                for ($i = 0; $i < count($varyasyonlar); $i++):
                    $degerler = explode(",", $varyasyonlar[$i]->degerler);
                    for ($k = 0; $k < $paketler[0]->urun_adet; $k++):
                        ?>
                        <div class="form-group select-container">
                            <select name="varyasyon[<?= strtolower(str_replace([" "], ["_"], $varyasyonlar[$i]->baslik)); ?>][]" class="form-control input-lg smart-payment-select" required>
                                <option value="" disabled selected><?= $k + 1; ?>. <?= $varyasyonlar[$i]->baslik; ?> Seçin</option>
                                <?php
                                foreach ($degerler as $deger) {
                                    echo "<option value='{$deger}'>{$deger}</option>";
                                }
                                ?>
                            </select>
                        </div>
                    <?php
                    endfor;
                    echo "<hr />";
                endfor;
                echo "</div>";
            endif;
            ?>
            <!-- varyasyonlar -->

<!-- Eski ödeme tipi - arka plan için gizli tutuldu -->
<div class="form-group" style="display: none;">
<select name="odeme_tipi" class="custom-select cusem checkvalid">
<option value="">ÖDEME TİPİ</option>
                    <?php
                    foreach ($odeme_tipleri as $od):
                        // PayPal'ı otomatik seçili yap (genellikle id=2 PayPal olur, kontrol edin)
                        $selected = (stripos($od["od_baslik"], 'paypal') !== false) ? 'selected' : '';
                        ?>
                        <option value="<?= $od["od_id"]; ?>" <?= $selected; ?>><?= $od["od_baslik"]; ?></option>
                    <?php
                    endforeach;
                    ?>
</select>
</div>

<!-- Yeni Ödeme Modülü -->
<div class="payment-module">
<p class="payment-title"><i class="fas fa-credit-card"></i> Ödeme Yönteminizi Seçin <i class="fas fa-chevron-down"></i></p>

<!-- Stripe Kredi Kartı Ödeme -->
<div class="payment-option">
    <input type="radio" name="payment_method" id="stripe_payment" value="stripe" class="d-none payment-radio">
    <label for="stripe_payment" class="payment-label">
        <div class="payment-header">
            <i class="payment-icon fas fa-credit-card"></i>
            <span class="payment-name">Kredi Kartı ile Ödeme</span>
            <span class="payment-secure"><i class="fas fa-shield-alt"></i> Güvenli</span>
        </div>
    </label>
    
    <div class="payment-details stripe-details" id="stripe_details" style="display: none;">
        <div class="payment-amount-info">
            <div class="amount-display">
                <span class="amount-label">Ödenecek Tutar:</span>
                <span class="payment-amount-display">0.00 €</span>
            </div>
        </div>
        <div class="stripe-form">
            <div class="stripe-loading" id="stripe-loading" style="display: block; text-align: center; padding: 20px;">
                <i class="fas fa-spinner fa-spin"></i> Kredi kartı alanları yükleniyor...
            </div>
            <div class="stripe-elements" id="stripe-elements" style="display: none;">
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>Kart Numarası</label>
                        <div id="stripe-card-number" class="stripe-element"></div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Son Kullanma</label>
                        <div id="stripe-card-expiry" class="stripe-element"></div>
                    </div>
                    <div class="form-group col-md-6">
                        <label>CVC</label>
                        <div id="stripe-card-cvc" class="stripe-element"></div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Kart Üzerindeki İsim</label>
                    <input type="text" id="stripe-cardholder-name" class="form-control" placeholder="Ad Soyad">
                </div>
                <div id="stripe-card-errors" class="text-danger" style="display: none;"></div>
            </div>
        </div>
    </div>
</div>

<!-- PayPal Ödeme -->
<div class="payment-option">
    <input type="radio" name="payment_method" id="paypal_payment" value="paypal" class="d-none payment-radio" checked>
    <label for="paypal_payment" class="payment-label">
        <div class="payment-header">
            <i class="payment-icon fab fa-paypal"></i>
            <span class="payment-name">PayPal ile Ödeme</span>
            <span class="payment-badge"><i class="fas fa-star"></i> Önerilen</span>
        </div>
    </label>
    
    <div class="payment-details paypal-details" id="paypal_details" style="display: block;">
        <div class="paypal-info">
            <p>PayPal hesabınız veya kredi kartınız ile güvenle ödeme yapabilirsiniz.</p>
            <div id="paypal-button-container"></div>
        </div>
    </div>
</div>

<!-- Havale/Western Union -->
<div class="payment-option">
    <input type="radio" name="payment_method" id="bank_transfer" value="bank_transfer" class="d-none payment-radio">
    <label for="bank_transfer" class="payment-label">
        <div class="payment-header">
            <i class="payment-icon fas fa-university"></i>
            <span class="payment-name">Havale / Western Union</span>
            <span class="payment-note"><i class="fas fa-clock"></i> Manuel İşlem</span>
        </div>
    </label>
    
    <div class="payment-details transfer-details" id="transfer_details" style="display: none;">
        <div class="payment-amount-info">
            <div class="amount-display">
                <span class="amount-label">Ödenecek Tutar:</span>
                <span class="payment-amount-display">0.00 €</span>
            </div>
        </div>
        <div class="transfer-info">
            <div class="alert alert-info">
                <strong><i class="fas fa-phone"></i> Siparişinizi tamamlayın</strong><br>
                Sipariş onayınızdan sonra size havale bilgilerimizi göndereceğiz.<br>
                Western Union için de aynı şekilde iletişime geçeceğiz.
            </div>
        </div>
    </div>
</div>

</div>




</div>
<div class="payment">

<div class="form-group">
<button type="submit" id="button" name="form_btn" class="btn shadow"><i class="fas fa-check-circle"></i> Siparişimi Tamamla</button>
</div>
</div>








<div class="approve">
<div class="form-group custom-control custom-checkbox cucheck">
<input type="checkbox" class="custom-control-input cuinput checkvalid" id="information" checked required disabled>
<label class="custom-control-label culabel" for="information"><b data-source="#salesco" data-target="#datapop">Mesafeli Satış Sözleşmesi ve Ön Bilgi Formu</b> 'nu okudum ve kabul ediyorum. Bu bilgiyi göndererek web sayfasının Gizlilik politikasını kabul ediyorum.</label>
<abbr class="invalid-feedback">lütfen, satış sözleşmesini onaylayınız !</abbr>
</div>
</div>
</div>
</div>
</form>
</div>
<div class="container-fluid cargos">
<img src="img/cargo.png" alt="Kargo Firmaları">
</div>
</main>
<footer>
<div class="container">
<div class="row">
<div class="col-12 order-md-last copy">MİRANA™ DEFNE YAPRAKLI KAKTÜS MACUNU | All Rights Reserved.</div>

<div class="col-12 order-md-first base">
<div class="row">
<div class="col-md-auto mr-auto align-self-center">

</div>
<div class="col col-md-auto">

<span>
<a href="#" target="_blank" class="btn"><i class="fab fa-facebook"></i></a>
<a href="#" target="_blank" class="btn"><i class="fab fa-youtube"></i></a>
<a href="#" target="_blank" class="btn"><i class="fab fa-instagram"></i></a>
</span>
</div>
</div>
</div>
</div>
</div>
</footer>


	<script src="https://code.jquery.com/jquery-latest.js"></script>
	<script src="js/form.js"></script>
	<script src="js/payment-module.js?v=1.6.0"></script>
	<script>
	// Initialize Payment Module
	document.addEventListener('DOMContentLoaded', function() {
		try {
			const paymentModule = new PaymentModule();
			paymentModule.init().catch(error => {
				console.error('Payment module initialization failed:', error);
				// Show user-friendly error message
				const paymentModuleDiv = document.querySelector('.payment-module');
				if (paymentModuleDiv) {
					paymentModuleDiv.innerHTML = `
						<div style="text-align: center; padding: 20px; color: #dc3545; border: 1px solid #f5c6cb; background: #f8d7da; border-radius: 8px;">
							<i class="fas fa-exclamation-triangle"></i> Ödeme sistemi yüklenirken hata oluştu.
							<br><br>
							<button onclick="window.location.reload()" class="btn btn-primary">
								<i class="fas fa-refresh"></i> Sayfayı Yenile
							</button>
						</div>
					`;
				}
			});
		} catch (error) {
			console.error('Failed to create PaymentModule:', error);
		}
	});
	</script>
<script src="img/app.js?v=1.1.9" type="a902e661dc72202d92420928-text/javascript"></script>
<style></style> <script type="a902e661dc72202d92420928-text/javascript"></script>
<script src="js/template.js" type="a902e661dc72202d92420928-text/javascript"></script>


<script src="https://ajax.cloudflare.com/cdn-cgi/scripts/7089c43e/cloudflare-static/rocket-loader.min.js" data-cf-settings="a902e661dc72202d92420928-|49" defer=""></script></body>
</html>
