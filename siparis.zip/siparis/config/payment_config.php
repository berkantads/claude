<?php
// Payment Configuration File
// Ödeme API anahtarları ve ayarları

// Stripe Configuration
define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51NNYo1BYyd0bfLOIUiNOq6OypoBFtZ3psabQmK0HXdsPk4A9sF2MQrUOslV20QaBoyxg9ol4gJjPgutWzW4cDpR000ARLIVECY'); // Public key for frontend
define('STRIPE_SECRET_KEY', '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'); // Secret key for backend
define('STRIPE_WEBHOOK_SECRET', 'whsec_YOUR_WEBHOOK_SECRET_HERE'); // Optional: for webhooks

// PayPal Configuration  
define('PAYPAL_CLIENT_ID', 'Ad0AlQAECvDlYgVY6XmNLwX2A-cYV6Dl8VQaopDIeOxPoA_Z_k5IwMNMcGp2jht-CUaDLYFl62jo0IGW'); // Public key for frontend
define('PAYPAL_CLIENT_SECRET', 'EHjZMG8ogJsOErZN7qyhO84B4zcg6mS7vd3ZgqG5O3VOU6ErvA_j1jH4IyFpuy0Ajd4EPFJ60JGRAYZr'); // Secret for backend verification
define('PAYPAL_ENVIRONMENT', 'production'); // 'sandbox' for testing, 'production' for live

// Payment Settings
define('DEFAULT_CURRENCY', 'EUR');
define('PAYMENT_TIMEOUT', 300); // 5 minutes in seconds

// Bank Transfer Information
define('BANK_NAME', 'Your Bank Name');
define('BANK_ACCOUNT_NAME', 'Your Account Name');
define('BANK_ACCOUNT_NUMBER', 'Your Account Number');
define('BANK_IBAN', 'Your IBAN');
define('BANK_SWIFT', 'Your SWIFT Code');

// Western Union Information  
define('WU_RECEIVER_NAME', 'Your Western Union Receiver Name');
define('WU_RECEIVER_ADDRESS', 'Your Address');
define('WU_RECEIVER_CITY', 'Your City');
define('WU_RECEIVER_COUNTRY', 'Your Country');

// Email Templates
$email_templates = [
    'bank_transfer' => [
        'subject' => 'Havale Bilgileri - Sipariş #{order_id}',
        'body' => '
            <h2>Sayın {customer_name},</h2>
            <p>Siparişiniz başarıyla alınmıştır. Sipariş numaranız: <strong>#{order_id}</strong></p>
            
            <h3>Havale Bilgileri:</h3>
            <ul>
                <li><strong>Banka Adı:</strong> ' . BANK_NAME . '</li>
                <li><strong>Hesap Adı:</strong> ' . BANK_ACCOUNT_NAME . '</li>
                <li><strong>Hesap Numarası:</strong> ' . BANK_ACCOUNT_NUMBER . '</li>
                <li><strong>IBAN:</strong> ' . BANK_IBAN . '</li>
                <li><strong>SWIFT:</strong> ' . BANK_SWIFT . '</li>
            </ul>
            
            <p><strong>Ödenecek Tutar:</strong> {amount} {currency}</p>
            <p><strong>Açıklama:</strong> Sipariş #{order_id} - {customer_name}</p>
            
            <p>Havale işleminizi tamamladıktan sonra ödeme dekontu ile birlikte bize ulaşın.</p>
            
            <h3>Western Union Bilgileri:</h3>
            <ul>
                <li><strong>Alıcı Adı:</strong> ' . WU_RECEIVER_NAME . '</li>
                <li><strong>Alıcı Adresi:</strong> ' . WU_RECEIVER_ADDRESS . '</li>
                <li><strong>Şehir:</strong> ' . WU_RECEIVER_CITY . '</li>
                <li><strong>Ülke:</strong> ' . WU_RECEIVER_COUNTRY . '</li>
            </ul>
            
            <p>Teşekkürler!</p>
        '
    ],
    'payment_success' => [
        'subject' => 'Ödeme Onayı - Sipariş #{order_id}',
        'body' => '
            <h2>Sayın {customer_name},</h2>
            <p>Ödemeniz başarıyla alınmıştır!</p>
            <p>Sipariş numaranız: <strong>#{order_id}</strong></p>
            <p>Ödeme tutarı: <strong>{amount} {currency}</strong></p>
            <p>Ödeme yöntemi: <strong>{payment_method}</strong></p>
            <p>Referans numarası: <strong>{payment_reference}</strong></p>
            
            <p>Siparişiniz en kısa sürede hazırlanacak ve size ulaşacaktır.</p>
            <p>Teşekkürler!</p>
        '
    ]
];

// Error Messages
$error_messages = [
    'tr' => [
        'invalid_card' => 'Geçersiz kart bilgileri',
        'insufficient_funds' => 'Yetersiz bakiye',
        'card_declined' => 'Kart reddedildi',
        'payment_failed' => 'Ödeme işlemi başarısız',
        'network_error' => 'Ağ bağlantı hatası',
        'invalid_amount' => 'Geçersiz tutar',
        'payment_timeout' => 'Ödeme zaman aşımı',
        'duplicate_order' => 'Bu sipariş zaten mevcut'
    ],
    'en' => [
        'invalid_card' => 'Invalid card information',
        'insufficient_funds' => 'Insufficient funds',
        'card_declined' => 'Card declined',
        'payment_failed' => 'Payment failed',
        'network_error' => 'Network connection error',
        'invalid_amount' => 'Invalid amount',
        'payment_timeout' => 'Payment timeout',
        'duplicate_order' => 'This order already exists'
    ]
];

// Success Messages
$success_messages = [
    'tr' => [
        'payment_success' => 'Ödeme başarıyla tamamlandı',
        'order_created' => 'Sipariş başarıyla oluşturuldu',
        'bank_transfer_pending' => 'Siparişiniz alındı. Havale bilgileri e-posta ile gönderildi.'
    ],
    'en' => [
        'payment_success' => 'Payment completed successfully',
        'order_created' => 'Order created successfully',
        'bank_transfer_pending' => 'Order received. Bank transfer information sent via email.'
    ]
];

// Payment Method Display Names
$payment_method_names = [
    'stripe' => 'Kredi Kartı',
    'paypal' => 'PayPal',
    'bank_transfer' => 'Havale/Western Union'
];

// Allowed currencies for each payment method
$allowed_currencies = [
    'stripe' => ['EUR', 'USD', 'GBP', 'TRY'],
    'paypal' => ['EUR', 'USD', 'GBP'],
    'bank_transfer' => ['EUR', 'USD', 'TRY']
];

// Minimum amounts for each payment method (to prevent very small transactions)
$minimum_amounts = [
    'stripe' => ['EUR' => 0.50, 'USD' => 0.50, 'GBP' => 0.30, 'TRY' => 10.00],
    'paypal' => ['EUR' => 1.00, 'USD' => 1.00, 'GBP' => 1.00],
    'bank_transfer' => ['EUR' => 10.00, 'USD' => 10.00, 'TRY' => 100.00]
];

// Security settings
define('PAYMENT_LOG_ENABLED', true); // Log all payment attempts
define('FRAUD_CHECK_ENABLED', true); // Enable basic fraud checks
define('MAX_PAYMENT_ATTEMPTS', 3); // Max attempts per IP per hour
define('PAYMENT_ATTEMPT_WINDOW', 3600); // 1 hour in seconds

// Webhook URLs (for payment confirmations)
$webhook_urls = [
    'stripe' => '/webhooks/stripe.php',
    'paypal' => '/webhooks/paypal.php'
];

// Development/Testing flags
define('PAYMENT_DEBUG_MODE', false); // Set to true for development
define('SKIP_PAYMENT_VERIFICATION', false); // Set to true ONLY for testing

// Function to get payment configuration
function getPaymentConfig($key = null) {
    global $email_templates, $error_messages, $success_messages, 
           $payment_method_names, $allowed_currencies, $minimum_amounts, $webhook_urls;
    
    $config = [
        'email_templates' => $email_templates,
        'error_messages' => $error_messages,
        'success_messages' => $success_messages,
        'payment_method_names' => $payment_method_names,
        'allowed_currencies' => $allowed_currencies,
        'minimum_amounts' => $minimum_amounts,
        'webhook_urls' => $webhook_urls
    ];
    
    return $key ? ($config[$key] ?? null) : $config;
}

// Function to validate payment method
function isValidPaymentMethod($method) {
    return in_array($method, ['stripe', 'paypal', 'bank_transfer']);
}

// Function to validate currency for payment method
function isValidCurrency($method, $currency) {
    $allowed = getPaymentConfig('allowed_currencies')[$method] ?? [];
    return in_array($currency, $allowed);
}

// Function to check minimum amount
function checkMinimumAmount($method, $currency, $amount) {
    $minimums = getPaymentConfig('minimum_amounts')[$method] ?? [];
    $minimum = $minimums[$currency] ?? 0;
    return $amount >= $minimum;
}
?> 