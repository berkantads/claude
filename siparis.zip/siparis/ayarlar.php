<?php

error_reporting(E_ALL);

require "classes/db.php";

require "db_conf.php";

$db = new DB();

$domain = str_replace(["https://", "http://", "www."], ["", "", ""], $_SERVER["SERVER_NAME"]);

$site = $db->getirTek("siteler", ["site_url" => $domain]);


function getIP()

{

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {

        $ip = $_SERVER['HTTP_CLIENT_IP'];

    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {

        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

    } else {

        $ip = $_SERVER['REMOTE_ADDR'];

    }

    return $ip;

}


if (!$site) {

    exit("Site bulunamadı. Panelden sitenin eklenmesi gerekmektedir.");

} else {

    $urun = $db->getirTek("urunler", ["urun_id" => $site["site_urun"]]);

    $sehirler = $db->getir("adres_sehirler", ["sehir_durum" => 1], "sehir_adi asc");

    $odeme_tipleri = $db->getir("odeme_yontemleri", ["od_durum" => 1], "od_baslik asc");

    $paketler = json_decode($urun["urun_paketler"]);

    $varyasyonlar = json_decode($urun["urun_varyasyonlar"]);

}