<?php
require "ayarlar.php";
if ($_POST["sehir"]) {
    $ilceler = $db->getir("adres_ilceler", ["sehir_id" => $_POST["sehir"]], "ilce_adi asc");
    $cikti = "";
    foreach ($ilceler as $ilce) {
        echo "<option value='{$ilce["ilce_id"]}'>{$ilce["ilce_adi"]}</option>";
    }
}