<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

require "config/payment_config.php";

// Only return public/safe configuration data for frontend
$frontendConfig = [
    'stripe' => [
        'publishable_key' => STRIPE_PUBLISHABLE_KEY,
        'currency' => DEFAULT_CURRENCY
    ],
    'paypal' => [
        'client_id' => PAYPAL_CLIENT_ID,
        'environment' => PAYPAL_ENVIRONMENT,
        'currency' => DEFAULT_CURRENCY
    ],
    'general' => [
        'currency' => DEFAULT_CURRENCY,
        'minimum_amounts' => getPaymentConfig('minimum_amounts'),
        'payment_methods' => ['stripe', 'paypal', 'bank_transfer']
    ]
];

echo json_encode($frontendConfig);
?> 