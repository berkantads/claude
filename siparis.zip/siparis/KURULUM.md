# Ödeme Modülü Kurulum Rehberi

## 🚀 Hızlı Başlangıç

### 1. Composer ile Stripe SDK'yı Kurun
```bash
cd siparis/
composer install
```

### 2. Veritabanı Güncellemeleri
```bash
# Önce yedek alın
mysqldump -u username -p database_name siparisler > backup_$(date +%Y%m%d_%H%M%S).sql

# Sonra güncellemeleri uygulayın
mysql -u username -p database_name < database_update.sql
```

### 3. API Anahtarları Kontrolü
API anahtarları zaten `config/payment_config.php` dosyasında güncellenmiştir:

- ✅ Stripe Live Keys
- ✅ PayPal Production Keys  
- ✅ Production Environment

### 4. Dosya İzinleri
```bash
chmod 644 config/payment_config.php
chmod 644 get_payment_config.php
chmod 644 process_payment.php
```

### 5. SSL Sertifikası
⚠️ **Önemli:** Production ortamında mutlaka SSL sertifikası olmalı!
- Stripe ve PayPal HTTPS gerektiriyor
- Kullanıcı güvenliği için kritik

### 6. Test Etme

#### Stripe Test Kartları:
- **Başarılı:** `4242424242424242`
- **Declined:** `4000000000000002`
- **3D Secure:** `4000002500003155`

#### PayPal:
- PayPal sandbox hesabı ile test edin
- Production'da gerçek PayPal hesabı gerekli

#### Havale/Western Union:
- Sipariş oluşturulur ve email gönderilir
- Manuel onay sistemi

## 🔧 Yapılandırma

### Banka Bilgileri Güncelleme
`config/payment_config.php` dosyasında:
```php
define('BANK_NAME', 'Sizin Banka Adınız');
define('BANK_ACCOUNT_NAME', 'Hesap Adı');
define('BANK_IBAN', 'TR00 0000 0000 0000 0000 00');
```

### Email Ayarları
Email gönderimi için SMTP ayarlarınızı kontrol edin.

### Para Birimi
Varsayılan para birimi EUR olarak ayarlandı. Değiştirmek için:
```php
define('DEFAULT_CURRENCY', 'USD'); // veya TRY
```

## 🔐 Güvenlik

### API Anahtarları
- ✅ Production anahtarları kullanılıyor
- ✅ Secret key'ler backend'de saklı
- ✅ Public key'ler dinamik olarak yükleniyor

### Güvenlik Kontrolleri
- SQL Injection koruması
- XSS koruması  
- Rate limiting
- Duplicate order kontrolü
- Payment logging

## 📱 Desteklenen Ödeme Yöntemleri

### 💳 Stripe (Kredi Kartı)
- Visa, Mastercard, American Express
- 3D Secure desteği
- Anında onay
- Otomatik fraud koruması

### 🏦 PayPal
- PayPal hesabı ile ödeme
- Kredi kartı ile PayPal üzerinden
- Buyer protection
- Uluslararası ödemeler

### 🏧 Havale/Western Union
- Manuel işlem
- Email ile bilgilendirme
- Ödeme dekont kontrolü
- Admin onayı gerekli

## 🐛 Sorun Giderme

### Stripe Hataları
```javascript
// Console'da hata kontrol edin
console.log('Stripe error:', error);
```

### PayPal Hataları
```javascript
// PayPal debug mode
console.log('PayPal error:', err);
```

### Veritabanı Hataları
```sql
-- Siparişleri kontrol edin
SELECT * FROM siparisler ORDER BY sp_id DESC LIMIT 10;

-- Ödeme loglarını kontrol edin  
SELECT * FROM payment_logs ORDER BY id DESC LIMIT 10;
```

## 📞 Destek

Sorun yaşarsanız:

1. Browser console'ı kontrol edin
2. Server error log'larını kontrol edin
3. Veritabanı bağlantısını test edin
4. SSL sertifikasını kontrol edin

## 🚀 Production Checklist

- [ ] SSL sertifikası aktif
- [ ] Composer dependencies yüklü
- [ ] Veritabanı güncellemeleri uygulandı
- [ ] API anahtarları production keys
- [ ] Email SMTP ayarları yapıldı
- [ ] Banka bilgileri güncellendi
- [ ] Test ödemeleri yapıldı
- [ ] Error logging aktif
- [ ] Backup stratejisi mevcut

## 🎯 Performans

- Payment config cache'leniyor
- Minimal JavaScript yükü
- Responsive tasarım
- Mobile optimized
- Progressive enhancement

---

**⚠️ Önemli Notlar:**
- Bu production anahtarları gerçek para işlemleri yapar
- Test etmeden önce küçük tutarlar kullanın
- API anahtarlarını asla public repository'ye commit etmeyin
- Regular security audit'lar yapın 