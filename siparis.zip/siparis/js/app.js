// Basic App.js - Prevents 404 errors
// This file provides basic application utilities

console.log('App.js loaded successfully');

// Basic utility functions
window.App = {
    // Initialize any global app functions here
    init: function() {
        console.log('App initialized');
    },

    // Utility function for safe element selection
    $: function(selector) {
        return document.querySelector(selector);
    },

    // Utility function for multiple element selection
    63804: function(selector) {
        return document.querySelectorAll(selector);
    }
};

// Auto-initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    if (window.App && typeof window.App.init === 'function') {
        window.App.init();
    }
});
