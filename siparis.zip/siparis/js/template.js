// Check if config is defined before proceeding
if (typeof config !== 'undefined' && config) {
    try {
        var conf = $.parseJSON(config);
        var comment_list = $('#comment-list');
        var comment_item = comment_list.find('.item').first();
        comment_list.html('');
        $('#c-count').html(conf.comments.length);
        
        conf.comments.forEach(function(comment) {
            var c_item = comment_item.clone();
            c_item.find('.comment-name').html(comment.fullname);
            c_item.find('.comment-star').attr('src', 'assets/1/c-star_' + comment.rate + '.png');
            c_item.find('.comment-message').html(comment.message);
            c_item.find('.comment-like').html(comment.like);
            
            if (comment.images.length > 0) {
                c_item.find('.comment-gallery').html('');
                comment.images.forEach(function(image) {
                    c_item.find('.comment-gallery').append('<a class="gallery-item"><img src="storage/' + image.path + '" /></a>');
                });
            } else if (comment.video != null) {
                var video_item = '<script src="https://fast.wistia.com/embed/medias/' + comment.video + '.jsonp" async></script>' +
                    '<script src="https://fast.wistia.com/assets/external/E-v1.js" async></script>' +
                    '<div class="wistia_embed wistia_async_' + comment.video + '" style="height:32rem;position:relative;width:100%;">' +
                    '<div class="wistia_swatch" style="height:100%;left:0;opacity:0;overflow:hidden;position:absolute;top:0;transition:opacity 200ms;width:100%;">' +
                    '<img src="https://fast.wistia.com/embed/medias/' + comment.video + '/swatch" style="filter:blur(5px);height:110%;object-fit:contain;width:100%;" alt="" aria-hidden="true" onload="this.parentNode.style.opacity=1;">' +
                    '</div>' +
                    '</div>';
                c_item.find('.comment-gallery').html('');
                c_item.find('.comment-gallery').append(video_item);
            } else {
                console.log(comment.video);
                c_item.find('.comment-gallery').remove();
            }
            comment_list.append(c_item);
        });

        var product_list = $('#product-list');
        if (product_list.prop('tagName') == 'SELECT') {
            product_list.html('');
            conf.products.forEach(function(product) {
                var item = '<option value="' + product.id + '">' + product.product_name + '</option>';
                product_list.append(item);
            });
        } else {
            var product_item = product_list.find('.item').first();
            product_list.html('');
            var i = 1;
            conf.products.forEach(function(product) {
                var p_item = product_item.clone();
                p_item.find('.product-id').val(product.id);
                p_item.find('.product-id').attr('id', 'packet' + i);
                p_item.find('label').removeAttr('for').attr('for', 'packet' + i);
                p_item.find('.title').html(product.product_name);
                p_item.find('.price-2').html(product.old_price);
                p_item.find('.price-1').html(product.price);
                p_item.attr('data-product-id', product.id);
                p_item.find('.p-img').attr('src', 'assets/6/product-' + i + '.png?v=1.0.2');
                if (product.cargo == 0) {
                    p_item.find('.subline').html('Kampanyalı Paket (Kargo Ücretsiz)');
                } else {
                    p_item.find('.p-cargo').html(product.cargo);
                }
                i++;
                product_list.append(p_item);
            });
            $('#product-list').find('.item').last().find('input').click();
        }
    } catch (error) {
        console.warn('Template.js: Error processing config:', error);
    }
} else {
    console.warn('Template.js: config variable not defined, skipping template processing');
}