// Payment Module JavaScript
class PaymentModule {
    constructor() {
        this.config = null;
        this.stripe = null;
        this.stripeElements = null;
        this.cardNumber = null;
        this.cardExpiry = null;
        this.cardCvc = null;
        this.stripeLoaded = false;
        this.stripeElementsInitialized = false; // Flag to prevent double initialization
        this.paypalInitializing = false; // Flag to prevent duplicate PayPal initialization
    }
    
    async init() {
        try {
            console.log('Starting payment module initialization...');
            await this.loadConfig();
            console.log('Config loaded:', this.config);
            this.setupPaymentMethodToggle();
            this.loadStripe();
            this.loadPayPal();
            this.setupFormSubmission();
            this.setupMobileOptimizations();
            console.log('Payment module initialized successfully');
        } catch (error) {
            console.error('Payment module initialization failed:', error);
            this.showError('Ödeme sistemi yüklenirken hata oluştu. Lütfen sayfayı yenileyin.');
        }
    }
    
    async loadConfig() {
        try {
            const response = await fetch('get_payment_config.php');
            if (!response.ok) {
                throw new Error('Config yüklenemedi');
            }
            this.config = await response.json();
        } catch (error) {
            console.error('Config load error:', error);
            // Fallback config for development
            this.config = {
                stripe: {
                    publishable_key: 'pk_live_51NNYo1BYyd0bfLOIUiNOq6OypoBFtZ3psabQmK0HXdsPk4A9sF2MQrUOslV20QaBoyxg9ol4gJjPgutWzW4cDpR000ARLIVECY',
                    currency: 'EUR'
                },
                paypal: {
                    client_id: 'Ad0AlQAECvDlYgVY6XmNLwX2A-cYV6Dl8VQaopDIeOxPoA_Z_k5IwMNMcGp2jht-CUaDLYFl62jo0IGW',
                    environment: 'production',
                    currency: 'EUR'
                },
                general: {
                    currency: 'EUR'
                }
            };
        }
    }
    
    setupPaymentMethodToggle() {
        const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
        
        paymentRadios.forEach(radio => {
            radio.addEventListener('change', () => {
                this.togglePaymentDetails(radio.value);
                this.syncPaymentMethodWithOldSelect(radio.value);
            });
        });
        
        // Initialize with default selection
        const checkedRadio = document.querySelector('input[name="payment_method"]:checked');
        if (checkedRadio) {
            this.togglePaymentDetails(checkedRadio.value);
            this.syncPaymentMethodWithOldSelect(checkedRadio.value);
        }
        
        // Listen for package changes to update prices
        this.setupPackageListener();
    }
    
    syncPaymentMethodWithOldSelect(paymentMethod) {
        const oldSelect = document.querySelector('select[name="odeme_tipi"]');
        if (!oldSelect) {
            console.warn('Old payment select not found');
            return;
        }
        
        // Debug: log all available options
        console.log('Available payment options in old select:');
        const options = oldSelect.querySelectorAll('option');
        options.forEach((option, index) => {
            console.log(`${index}: value="${option.value}" text="${option.textContent}"`);
        });
        
        // Find the option that matches our payment method
        let selectedValue = '';
        
        options.forEach(option => {
            const optionText = option.textContent.toLowerCase();
            const optionValue = option.value.toLowerCase();
            
            if (paymentMethod === 'stripe' && (optionText.includes('kredi') || optionText.includes('kart') || optionText.includes('card'))) {
                selectedValue = option.value;
            } else if (paymentMethod === 'paypal' && optionText.includes('paypal')) {
                selectedValue = option.value;
            } else if (paymentMethod === 'bank_transfer' && (optionText.includes('havale') || optionText.includes('transfer') || optionText.includes('banka'))) {
                selectedValue = option.value;
            }
        });
        
        // If we found a matching option, select it
        if (selectedValue) {
            oldSelect.value = selectedValue;
            console.log(`✅ Synced payment method: ${paymentMethod} -> ${selectedValue}`);
        } else {
            // Fallback: try to find by payment method name directly
            options.forEach(option => {
                if (option.value.toLowerCase().includes(paymentMethod) || 
                    option.textContent.toLowerCase().includes(paymentMethod)) {
                    oldSelect.value = option.value;
                    selectedValue = option.value;
                }
            });
            
            if (selectedValue) {
                console.log(`✅ Synced payment method (fallback): ${paymentMethod} -> ${selectedValue}`);
            } else {
                console.warn(`❌ Could not sync payment method: ${paymentMethod}`);
                console.warn('Available options:', Array.from(options).map(o => ({value: o.value, text: o.textContent})));
            }
        }
    }
    
    setupPackageListener() {
        const packageRadios = document.querySelectorAll('input[name="paket"]');
        
        packageRadios.forEach(radio => {
            radio.addEventListener('change', () => {
                this.updatePaymentAmounts();
                this.reloadPayPal();
            });
        });
        
        // Initial price update
        this.updatePaymentAmounts();
    }
    
    updatePaymentAmounts() {
        const packageInfo = this.getSelectedPackageInfo();
        if (!packageInfo) return;
        
        // Update payment display amounts
        const amountDisplays = document.querySelectorAll('.payment-amount-display');
        amountDisplays.forEach(display => {
            display.textContent = `${packageInfo.total.toFixed(2)} €`;
        });
        
        // Update PayPal display
        const paypalInfo = document.querySelector('.paypal-info p');
        if (paypalInfo) {
            paypalInfo.innerHTML = `PayPal hesabınız veya kredi kartınız ile güvenle ödeme yapabilirsiniz.<br>
                                   <strong>Ödenecek Tutar: ${packageInfo.total.toFixed(2)} €</strong>`;
        }
        
        console.log('Updated payment amount:', packageInfo);
    }
    
    reloadPayPal() {
        // Reset the initialization flag
        this.paypalInitializing = false;
        
        // Clear existing PayPal buttons
        const container = document.getElementById('paypal-button-container');
        if (container) {
            container.innerHTML = '';
        }
        
        // Add loading indicator
        if (container) {
            container.innerHTML = '<div style="text-align: center; padding: 10px; color: #666;"><i class="fas fa-spinner fa-spin"></i> PayPal yükleniyor...</div>';
        }
        
        // Reload PayPal with new amount - longer delay to prevent race conditions
        setTimeout(() => {
            if (typeof paypal !== 'undefined' && container && container.isConnected) {
                this.initPayPal();
            } else {
                console.warn('PayPal reload failed: container not available or PayPal not loaded');
                if (container) {
                    this.showPayPalError('PayPal yeniden yüklenemedi');
                }
            }
        }, 300); // Increased delay for better stability
    }
    
    togglePaymentDetails(selectedMethod) {
        // Hide all payment details
        document.querySelectorAll('.payment-details').forEach(detail => {
            detail.style.display = 'none';
            detail.classList.remove('show');
        });
        
        // Show selected payment details
        const selectedDetails = document.getElementById(`${selectedMethod}_details`);
        if (selectedDetails) {
            selectedDetails.style.display = 'block';
            setTimeout(() => {
                selectedDetails.classList.add('show');
            }, 50);
        }
        
        // Initialize Stripe elements when Stripe payment is selected
        if (selectedMethod === 'stripe') {
            if (!this.stripeLoaded) {
                // Use async initialization
                this.initStripeElements().catch(error => {
                    console.error('Failed to initialize Stripe:', error);
                });
            } else if (!this.cardNumber || !this.cardExpiry || !this.cardCvc) {
                // Re-initialize if elements are missing
                console.log('Re-initializing missing Stripe elements');
                this.initStripeElements().catch(error => {
                    console.error('Failed to re-initialize Stripe:', error);
                });
            } else {
                // Check if elements are still mounted
                const cardNumberContainer = document.getElementById('stripe-card-number');
                const cardExpiryContainer = document.getElementById('stripe-card-expiry');
                const cardCvcContainer = document.getElementById('stripe-card-cvc');
                
                if (!cardNumberContainer?.hasChildNodes() || !cardExpiryContainer?.hasChildNodes() || !cardCvcContainer?.hasChildNodes()) {
                    console.log('Stripe elements containers are empty, re-mounting');
                    this.initStripeElements().catch(error => {
                        console.error('Failed to re-mount Stripe elements:', error);
                    });
                }
            }
        }
        
        // Update payment option styling
        document.querySelectorAll('.payment-option').forEach(option => {
            option.classList.remove('selected');
        });
        
        const paymentElement = document.querySelector(`#${selectedMethod}_payment`);
        if (paymentElement) {
            const selectedOption = paymentElement.closest('.payment-option');
            if (selectedOption) {
                selectedOption.classList.add('selected');
            }
        }
    }
    
    async loadStripe() {
        if (this.stripe) {
            return Promise.resolve(); // Already loaded
        }
        
        try {
            if (typeof Stripe === 'undefined') {
                console.log('Loading Stripe script...');
                await this.loadStripeScript();
            }
            
            if (!this.config?.stripe?.publishable_key) {
                throw new Error('Stripe publishable key not found');
            }
            
            this.stripe = Stripe(this.config.stripe.publishable_key);
            this.stripeElements = this.stripe.elements();
            console.log('Stripe initialized successfully');
            
        } catch (error) {
            console.error('Stripe loading error:', error);
            this.showStripeError('Stripe yüklenemedi. Lütfen sayfayı yenileyin.');
            throw error;
        }
    }
    
    loadStripeScript() {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://js.stripe.com/v3/';
            script.onload = () => {
                console.log('Stripe script loaded successfully');
                resolve();
            };
            script.onerror = () => {
                console.error('Failed to load Stripe script');
                reject(new Error('Stripe script loading failed'));
            };
            document.head.appendChild(script);
        });
    }
    
    async initStripeElements() {
        if (this.stripeElementsInitialized && this.cardNumber && this.cardExpiry && this.cardCvc) {
            console.log('Stripe elements already initialized and valid');
            this.showStripeLoading(false);
            return;
        }
        
        console.log('Initializing Stripe elements');
        
        try {
            // Show loading state immediately
            this.showStripeLoading(true);
            
            // Ensure Stripe is loaded
            await this.loadStripe();
            
            if (!this.stripe || !this.stripeElements) {
                throw new Error('Stripe not properly initialized');
            }
            
            // Check if containers exist
            const cardNumberContainer = document.getElementById('stripe-card-number');
            const cardExpiryContainer = document.getElementById('stripe-card-expiry');
            const cardCvcContainer = document.getElementById('stripe-card-cvc');
            
            if (!cardNumberContainer || !cardExpiryContainer || !cardCvcContainer) {
                throw new Error('Stripe containers not found in DOM');
            }
            
            // Clear existing elements if any
            this.destroyStripeElements();
            
            // Create card elements with mobile-friendly styling
            const style = {
                base: {
                    fontSize: '16px',
                    color: '#424770',
                    fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                    fontSmoothing: 'antialiased',
                    '::placeholder': {
                        color: '#aab7c4',
                    },
                },
                invalid: {
                    color: '#9e2146',
                },
            };
            
            // Create elements
            this.cardNumber = this.stripeElements.create('cardNumber', { 
                style,
                placeholder: '1234 1234 1234 1234'
            });
            this.cardExpiry = this.stripeElements.create('cardExpiry', { style });
            this.cardCvc = this.stripeElements.create('cardCvc', { style });
            
            // Mount elements with error handling
            try {
                console.log('Mounting Stripe elements');
                await this.cardNumber.mount('#stripe-card-number');
                await this.cardExpiry.mount('#stripe-card-expiry');
                await this.cardCvc.mount('#stripe-card-cvc');
                console.log('Stripe elements mounted successfully');
            } catch (mountError) {
                console.error('Error mounting Stripe elements:', mountError);
                throw new Error('Stripe elementleri yüklenirken hata: ' + mountError.message);
            }
            
            // Handle real-time validation errors
            this.cardNumber.on('change', this.handleStripeError.bind(this));
            this.cardExpiry.on('change', this.handleStripeError.bind(this));
            this.cardCvc.on('change', this.handleStripeError.bind(this));
            
            // Hide loading and show elements
            setTimeout(() => {
                this.showStripeLoading(false);
                const elementsDiv = document.getElementById('stripe-elements');
                if (elementsDiv) {
                    elementsDiv.classList.add('loaded');
                }
                this.stripeLoaded = true;
                this.stripeElementsInitialized = true; // Set flag on success
                console.log('Stripe elements initialized successfully');
            }, 300);
            
        } catch (error) {
            console.error('Stripe elements initialization error:', error);
            this.showStripeError(error.message || 'Kredi kartı alanları yüklenemedi');
            this.showStripeLoading(false);
        }
    }
    
    destroyStripeElements() {
        console.log('Destroying Stripe elements');
        try {
            if (this.cardNumber) {
                try {
                    this.cardNumber.unmount();
                    this.cardNumber.destroy();
                } catch (e) {
                    console.warn('Error unmounting/destroying cardNumber:', e);
                }
                this.cardNumber = null;
            }
            if (this.cardExpiry) {
                try {
                    this.cardExpiry.unmount();
                    this.cardExpiry.destroy();
                } catch (e) {
                    console.warn('Error unmounting/destroying cardExpiry:', e);
                }
                this.cardExpiry = null;
            }
            if (this.cardCvc) {
                try {
                    this.cardCvc.unmount();
                    this.cardCvc.destroy();
                } catch (e) {
                    console.warn('Error unmounting/destroying cardCvc:', e);
                }
                this.cardCvc = null;
            }
            
            // Clear containers to ensure clean state
            const containers = ['stripe-card-number', 'stripe-card-expiry', 'stripe-card-cvc'];
            containers.forEach(id => {
                const container = document.getElementById(id);
                if (container) {
                    container.innerHTML = '';
                }
            });
            
        } catch (error) {
            console.warn('Error destroying Stripe elements:', error);
            // Force reset elements even if destroy fails
            this.cardNumber = null;
            this.cardExpiry = null;
            this.cardCvc = null;
            this.stripeElementsInitialized = false; // Reset flag
        }
    }
    
    showStripeLoading(show) {
        const loadingDiv = document.getElementById('stripe-loading');
        const elementsDiv = document.getElementById('stripe-elements');
        
        if (show) {
            if (loadingDiv) {
                loadingDiv.style.display = 'block';
                loadingDiv.innerHTML = '<div style="text-align: center; padding: 20px; color: #666;"><i class="fas fa-spinner fa-spin"></i> Kredi kartı alanları yükleniyor...</div>';
            }
            if (elementsDiv) elementsDiv.style.display = 'none';
        } else {
            if (loadingDiv) loadingDiv.style.display = 'none';
            if (elementsDiv) elementsDiv.style.display = 'block';
        }
    }
    
         showStripeError(message) {
         const loadingDiv = document.getElementById('stripe-loading');
         if (loadingDiv) {
             loadingDiv.style.display = 'block';
             loadingDiv.innerHTML = `
                 <div style="text-align: center; padding: 20px; color: #dc3545;">
                     <i class="fas fa-exclamation-triangle"></i> ${message}
                     <br><br>
                     <button onclick="window.location.reload()" class="btn btn-sm btn-primary">
                         <i class="fas fa-refresh"></i> Sayfayı Yenile
                     </button>
                 </div>
             `;
         }
     }
     
     handleStripeError(event) {
         const errorElement = document.getElementById('stripe-card-errors');
         if (errorElement) {
             if (event.error) {
                 errorElement.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${event.error.message}`;
                 errorElement.classList.add('show');
             } else {
                 errorElement.classList.remove('show');
             }
         }
     }
    
    loadPayPal() {
        console.log('Loading PayPal...');
        this.debugPayPal();
        
        // Check network connectivity first
        if (!navigator.onLine) {
            console.error('No internet connection');
            this.showPayPalError('İnternet bağlantısı bulunamadı');
            return;
        }
        
        // Check if PayPal config is available
        if (!this.config || !this.config.paypal || !this.config.paypal.client_id) {
            console.error('PayPal config not found');
            this.showPayPalError('PayPal konfigürasyonu bulunamadı');
            return;
        }
        
        if (typeof paypal !== 'undefined') {
            this.initPayPal();
            return;
        }
        
        const script = document.createElement('script');
        script.src = `https://www.paypal.com/sdk/js?client-id=${this.config.paypal.client_id}&currency=${this.config.paypal.currency}`;
        
        // Add timeout for script loading
        let scriptLoaded = false;
        const timeout = setTimeout(() => {
            if (!scriptLoaded) {
                console.error('PayPal SDK loading timeout');
                this.showPayPalError('PayPal SDK yükleme zaman aşımı');
                script.remove();
            }
        }, 15000); // 15 second timeout
        
        script.onload = () => {
            scriptLoaded = true;
            clearTimeout(timeout);
            console.log('PayPal SDK loaded successfully');
            if (typeof paypal !== 'undefined') {
                this.initPayPal();
            } else {
                console.error('PayPal SDK loaded but paypal object not available');
                this.showPayPalError('PayPal SDK yüklenemedi');
            }
        };
        
        script.onerror = () => {
            scriptLoaded = true;
            clearTimeout(timeout);
            console.error('PayPal SDK script failed to load');
            this.showPayPalError('PayPal SDK yüklenirken hata oluştu');
        };
        
        document.head.appendChild(script);
    }
    
    initPayPal() {
        if (typeof paypal === 'undefined') {
            console.error('PayPal SDK not loaded');
            this.showPayPalError('PayPal SDK yüklenmedi');
            return;
        }
        
        if (this.paypalInitializing) {
            console.log('PayPal already initializing, skipping...');
            return; // Prevent multiple initializations
        }
        
        if (!this.checkPayPalContainer()) {
            this.showPayPalError('PayPal container bulunamadı');
            return;
        }
        
        const container = document.getElementById('paypal-button-container');
        
        // Ensure container is visible
        if (container.style.display === 'none') {
            container.style.display = 'block';
        }
        
        this.paypalInitializing = true;
        
        // Clear any existing PayPal buttons to prevent duplicates
        container.innerHTML = '';
        
        // Add a small delay to ensure proper cleanup and DOM stability
        setTimeout(() => {
            // Triple check container is still in DOM and visible
            if (!container || !container.isConnected || !document.contains(container)) {
                console.warn('PayPal container was removed from DOM during initialization');
                this.paypalInitializing = false;
                return;
            }
            
            // Check if container is visible
            if (container.offsetParent === null) {
                console.warn('PayPal container is not visible');
                this.paypalInitializing = false;
                return;
            }
            
            paypal.Buttons({
                createOrder: (data, actions) => {
                    const amount = this.calculateOrderAmount();
                    const packageInfo = this.getSelectedPackageInfo();
                    
                    if (amount <= 0) {
                        throw new Error('Lütfen bir paket seçin');
                    }
                    
                    return actions.order.create({
                        purchase_units: [{
                            amount: {
                                value: amount.toFixed(2),
                                currency_code: this.config.paypal.currency
                            },
                            description: packageInfo ? packageInfo.title : 'Sipariş'
                        }]
                    });
                },
                
                onApprove: async (data, actions) => {
                    try {
                        const order = await actions.order.capture();
                        await this.handlePayPalSuccess(order);
                    } catch (error) {
                        console.error('PayPal payment failed:', error);
                        this.showError('PayPal ödemesi tamamlanamadı. Lütfen tekrar deneyin.');
                    }
                },
                
                onError: (err) => {
                    console.error('PayPal error:', err);
                    this.showError('PayPal hatası. Lütfen tekrar deneyin.');
                },
                
                style: {
                    layout: 'vertical',
                    color: 'blue',
                    shape: 'rect',
                    label: 'paypal',
                    height: 35,  // Compact height for smaller buttons
                    tagline: false  // Remove tagline for cleaner look
                }
                         }).render('#paypal-button-container').then(() => {
                 this.paypalInitializing = false; // Reset flag on success
                 console.log('PayPal buttons rendered successfully');
             }).catch(err => {
                 this.paypalInitializing = false; // Reset flag on error
                 console.error('PayPal render error:', err);
                 this.showPayPalError('PayPal butonları yüklenemedi. Lütfen sayfayı yenileyin.');
             });
         }, 100);
    }
    
    showPayPalError(message) {
        const container = document.getElementById('paypal-button-container');
        if (container) {
            container.innerHTML = `
                <div style="
                    text-align: center; 
                    padding: 20px; 
                    color: #dc3545; 
                    border: 1px solid #f5c6cb; 
                    background: #f8d7da; 
                    border-radius: 8px;
                    margin: 10px 0;
                ">
                    <i class="fas fa-exclamation-triangle" style="margin-right: 8px;"></i>
                    ${message}
                    <br><br>
                    <button onclick="window.location.reload()" class="btn btn-sm btn-primary">
                        <i class="fas fa-refresh"></i> Sayfayı Yenile
                    </button>
                </div>
            `;
        }
        console.error('PayPal Error:', message);
    }
    
    checkPayPalContainer() {
        const container = document.getElementById('paypal-button-container');
        if (!container) {
            console.error('PayPal container element not found in DOM');
            return false;
        }
        
        if (!container.isConnected) {
            console.error('PayPal container not connected to DOM');
            return false;
        }
        
        if (container.offsetParent === null && container.style.display !== 'none') {
            console.warn('PayPal container might be hidden');
        }
        
        return true;
    }
    
    debugPayPal() {
        console.log('=== PayPal Debug Info ===');
        console.log('Config:', this.config);
        console.log('PayPal SDK loaded:', typeof paypal !== 'undefined');
        console.log('PayPal initializing:', this.paypalInitializing);
        console.log('Container exists:', !!document.getElementById('paypal-button-container'));
        console.log('Container connected:', document.getElementById('paypal-button-container')?.isConnected);
        console.log('Navigator online:', navigator.onLine);
        console.log('========================');
    }
    
    async handlePayPalSuccess(order) {
        console.log('PayPal payment successful:', order);
        
        try {
            // For PayPal, we need to submit to the original tamamla.php with PayPal info
            const form = document.getElementById('siparisformu');
            if (!form) {
                throw new Error('Form not found');
            }
            
            // Sync payment method with old select
            this.syncPaymentMethodWithOldSelect('paypal');
            
            // Add PayPal transaction info as hidden fields
            const paypalOrderId = document.createElement('input');
            paypalOrderId.type = 'hidden';
            paypalOrderId.name = 'paypal_order_id';
            paypalOrderId.value = order.id;
            form.appendChild(paypalOrderId);
            
            const paypalPaymentId = document.createElement('input');
            paypalPaymentId.type = 'hidden';
            paypalPaymentId.name = 'paypal_payment_id';
            paypalPaymentId.value = order.purchase_units[0].payments.captures[0].id;
            form.appendChild(paypalPaymentId);
            
            const paymentStatus = document.createElement('input');
            paymentStatus.type = 'hidden';
            paymentStatus.name = 'payment_status';
            paymentStatus.value = 'completed';
            form.appendChild(paymentStatus);
            
            console.log('Submitting PayPal order to tamamla.php');
            
            // Submit the form to original system
            form.submit();
            
        } catch (error) {
            console.error('PayPal success handling error:', error);
            this.showError('PayPal ödemesi tamamlandı ancak sipariş kaydedilirken hata oluştu: ' + error.message);
        }
    }
    
    setupFormSubmission() {
        const form = document.getElementById('siparisformu');
        const submitButton = document.getElementById('button');
        
        if (form && submitButton) {
            submitButton.addEventListener('click', async (e) => {
                const selectedPaymentMethod = document.querySelector('input[name="payment_method"]:checked')?.value;
                
                // Only intercept Stripe and PayPal payments
                // Let bank_transfer use the original form submission to Laravel
                if (selectedPaymentMethod === 'stripe' || selectedPaymentMethod === 'paypal') {
                    e.preventDefault();
                    await this.handleFormSubmit();
                } else {
                    // For bank_transfer, let the original form submit normally
                    console.log('Using original form submission for:', selectedPaymentMethod);
                    
                    // Ensure the old select has the correct value
                    this.syncPaymentMethodWithOldSelect(selectedPaymentMethod || 'bank_transfer');
                    
                    // Validate form before allowing submission
                    if (!this.validateForm()) {
                        e.preventDefault();
                        return false;
                    }
                    
                    // Let the form submit normally to tamamla.php
                    console.log('Form validation passed, submitting to tamamla.php');
                    return true;
                }
            });
        }
    }
    
    async handleFormSubmit() {
        // Validate form fields first
        if (!this.validateForm()) {
            return;
        }
        
        const selectedPaymentMethod = document.querySelector('input[name="payment_method"]:checked')?.value;
        
        if (!selectedPaymentMethod) {
            this.showError('Lütfen bir ödeme yöntemi seçin.');
            return;
        }
        
        this.showLoading(true);
        
        try {
            switch (selectedPaymentMethod) {
                case 'stripe':
                    await this.processStripePayment();
                    break;
                case 'paypal':
                    this.showError('PayPal butonunu kullanarak ödeme yapın.');
                    break;
                case 'bank_transfer':
                    await this.processBankTransfer();
                    break;
                default:
                    throw new Error('Geçersiz ödeme yöntemi');
            }
        } catch (error) {
            this.showError(error.message);
        } finally {
            this.showLoading(false);
        }
    }
    
    async processStripePayment() {
        console.log('Starting Stripe payment process');
        this.checkStripeElementsStatus();
        
        // Check if Stripe elements are properly loaded and mounted
        if (!this.cardNumber || !this.cardExpiry || !this.cardCvc) {
            this.showError('Kredi kartı alanları yüklenirken hata oluştu. Lütfen sayfayı yenileyin.');
            return;
        }
        
        // Check if elements are still mounted to DOM
        const cardNumberContainer = document.getElementById('stripe-card-number');
        const cardExpiryContainer = document.getElementById('stripe-card-expiry');
        const cardCvcContainer = document.getElementById('stripe-card-cvc');
        
        if (!cardNumberContainer || !cardExpiryContainer || !cardCvcContainer) {
            this.showError('Stripe elementleri bulunamadı. Lütfen sayfayı yenileyin.');
            return;
        }
        
        // Check if containers are connected to DOM
        if (!cardNumberContainer.isConnected || !cardExpiryContainer.isConnected || !cardCvcContainer.isConnected) {
            this.showError('Stripe elementleri DOM\'dan ayrıldı. Lütfen sayfayı yenileyin.');
            return;
        }
        
        const cardholderName = document.getElementById('stripe-cardholder-name').value;
        
        if (!cardholderName.trim()) {
            throw new Error('Kart üzerindeki ismi giriniz.');
        }
        
        const amount = this.calculateOrderAmount();
        const packageInfo = this.getSelectedPackageInfo();
        
        if (amount <= 0) {
            throw new Error('Lütfen bir paket seçin');
        }
        
        try {
            // Double-check elements before creating token
            if (!this.cardNumber || !this.cardNumber._element || !this.cardNumber._element.isConnected) {
                throw new Error('Kart numarası elementi bağlantısı kesildi');
            }
            
            const { token, error } = await this.stripe.createToken(this.cardNumber, {
                name: cardholderName
            });
            
            if (error) {
                throw new Error(error.message);
            }
            
            console.log('Stripe token created successfully:', token.id);
            
            // Submit to original form system with Stripe token
            const form = document.getElementById('siparisformu');
            if (!form) {
                throw new Error('Form not found');
            }
            
            // Sync payment method with old select
            this.syncPaymentMethodWithOldSelect('stripe');
            
            // Add Stripe token as hidden field
            const stripeTokenInput = document.createElement('input');
            stripeTokenInput.type = 'hidden';
            stripeTokenInput.name = 'stripe_token';
            stripeTokenInput.value = token.id;
            form.appendChild(stripeTokenInput);
            
            const paymentStatus = document.createElement('input');
            paymentStatus.type = 'hidden';
            paymentStatus.name = 'payment_status';
            paymentStatus.value = 'completed';
            form.appendChild(paymentStatus);
            
            console.log('Submitting Stripe payment to tamamla.php');
            
            // Submit the form to original system
            form.submit();
            
        } catch (error) {
            console.error('Stripe payment error:', error);
            throw error;
        }
    }
    
    /*
    // These methods are no longer needed since we're using the original Laravel form submission
    async processBankTransfer() {
        const orderData = this.getOrderData();
        orderData.payment_method = 'bank_transfer';
        orderData.amount = this.calculateOrderAmount();
        
        const response = await this.submitOrder(orderData);
        
        if (response.success) {
            this.redirectToSuccess();
        } else {
            throw new Error(response.message || 'Havale işlemi başarısız');
        }
    }
    
    getOrderData() {
        return {
            musteri: document.querySelector('input[name="musteri"]')?.value || '',
            telefon: document.querySelector('input[name="telefon"]')?.value || '',
            sehir: document.querySelector('select[name="sehir"]')?.value || '',
            ilce: document.querySelector('select[name="ilce"]')?.value || '',
            adres: document.querySelector('textarea[name="adres"]')?.value || '',
            paket: document.querySelector('input[name="paket"]:checked')?.value || ''
        };
    }
    
    redirectToSuccess() {
        window.location.href = 'siparis_tamamlandi.php';
    }
    */
    
    calculateOrderAmount() {
        const selectedPackage = document.querySelector('input[name="paket"]:checked');
        if (!selectedPackage) return 0;
     
        const price = parseFloat(selectedPackage.dataset.price || 0);
        const cargo = parseFloat(selectedPackage.dataset.cargo || 0);
        
        return price + cargo;
    }
    
    getSelectedPackageInfo() {
        const selectedPackage = document.querySelector('input[name="paket"]:checked');
        if (!selectedPackage) return null;
        
        return {
            index: selectedPackage.value,
            price: parseFloat(selectedPackage.dataset.price || 0),
            cargo: parseFloat(selectedPackage.dataset.cargo || 0),
            title: selectedPackage.dataset.title || '',
            total: parseFloat(selectedPackage.dataset.price || 0) + parseFloat(selectedPackage.dataset.cargo || 0)
        };
    }
    
    validateForm() {
        const requiredFields = [
            { field: 'musteri', message: 'Ad soyad gerekli' },
            { field: 'telefon', message: 'Telefon numarası gerekli' },
            { field: 'adres', message: 'Adres gerekli' }
        ];
        
        for (let { field, message } of requiredFields) {
            const input = document.querySelector(`[name="${field}"]`);
            if (!input || !input.value.trim()) {
                this.showError(message);
                if (input) input.focus();
                return false;
            }
        }
        
        // Check if package is selected
        const selectedPackage = document.querySelector('input[name="paket"]:checked');
        if (!selectedPackage) {
            this.showError('Lütfen bir paket seçin');
            return false;
        }
        
        return true;
    }
    
    setupMobileOptimizations() {
        // Touch event handling for mobile
        if ('ontouchstart' in window) {
            const paymentLabels = document.querySelectorAll('.payment-label');
            paymentLabels.forEach(label => {
                label.addEventListener('touchstart', function() {
                    this.style.backgroundColor = '#f8f9fa';
                });
                
                label.addEventListener('touchend', function() {
                    setTimeout(() => {
                        this.style.backgroundColor = '';
                    }, 150);
                });
            });
        }
        
        // Prevent zoom on input focus (iOS)
        const inputs = document.querySelectorAll('input[type="text"], input[type="tel"], input[type="email"], textarea');
        inputs.forEach(input => {
            if (input.getAttribute('data-zoom-disabled') !== 'true') {
                input.style.fontSize = '16px';
                input.setAttribute('data-zoom-disabled', 'true');
            }
        });
        
        // Optimize viewport for mobile payments
        const viewport = document.querySelector('meta[name="viewport"]');
        if (viewport && window.innerWidth <= 768) {
            viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
        }
    }
    
    showError(message) {
        // Create a better error display instead of alert
        console.error('Payment Error:', message);
        
        // Try to find an error container first
        let errorContainer = document.getElementById('payment-error-container');
        
        if (!errorContainer) {
            // Create error container if it doesn't exist
            errorContainer = document.createElement('div');
            errorContainer.id = 'payment-error-container';
            errorContainer.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: #dc3545;
                color: white;
                padding: 15px 20px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                z-index: 10000;
                max-width: 400px;
                font-size: 14px;
                line-height: 1.4;
            `;
            document.body.appendChild(errorContainer);
        }
        
        errorContainer.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-exclamation-triangle"></i>
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" style="
                    background: none;
                    border: none;
                    color: white;
                    font-size: 18px;
                    cursor: pointer;
                    margin-left: auto;
                    padding: 0;
                ">×</button>
            </div>
        `;
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (errorContainer && errorContainer.parentNode) {
                errorContainer.remove();
            }
        }, 5000);
    }
    
    showLoading(show) {
        const button = document.getElementById('button');
        const paymentModule = document.querySelector('.payment-module');
        
        if (show) {
            if (button) {
                button.disabled = true;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> İşleniyor...';
            }
            if (paymentModule) {
                paymentModule.classList.add('payment-loading');
            }
        } else {
            if (button) {
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-check-circle"></i> Siparişimi Tamamla';
            }
            if (paymentModule) {
                paymentModule.classList.remove('payment-loading');
            }
        }
    }
    
    redirectToSuccess() {
        window.location.href = 'siparis_tamamlandi.php';
    }

    checkStripeElementsStatus() {
        console.log('=== Stripe Elements Status ===');
        console.log('Stripe loaded:', !!this.stripe);
        console.log('Elements created:', !!this.stripeElements);
        console.log('CardNumber exists:', !!this.cardNumber);
        console.log('CardExpiry exists:', !!this.cardExpiry);
        console.log('CardCvc exists:', !!this.cardCvc);
        
        const containers = {
            'stripe-card-number': document.getElementById('stripe-card-number'),
            'stripe-card-expiry': document.getElementById('stripe-card-expiry'),
            'stripe-card-cvc': document.getElementById('stripe-card-cvc')
        };
        
        Object.entries(containers).forEach(([id, container]) => {
            console.log(`${id} container:`, {
                exists: !!container,
                connected: container?.isConnected,
                hasChildren: container?.hasChildNodes(),
                innerHTML: container?.innerHTML.length || 0
            });
        });
        
        console.log('==============================');
    }
}

// Payment module initialization is handled in the HTML file

// Export for external use if needed
window.PaymentModule = PaymentModule; 