<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set("display_errors", 1);

require "ayarlar.php";
require "classes/userAgent.php";
require "config/payment_config.php";

// CORS headers (if needed)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
    exit;
}

try {
    // Validate required fields
    $requiredFields = ['product_id', 'paket', 'musteri', 'telefon', 'adres', 'payment_method'];
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            throw new Exception("Eksik alan: $field");
        }
    }

    // Get selected package info
    $selectedPackageIndex = (int)$data['paket'];
    if (!isset($paketler[$selectedPackageIndex])) {
        throw new Exception("Geçersiz paket seçimi");
    }
    
    $seciliPaket = $paketler[$selectedPackageIndex];
    $kargoUcreti = ($seciliPaket->ucretsiz_kargo == 1) ? 0 : $seciliPaket->kargo_tutari;
    
    // Validate amount from frontend matches backend calculation
    $calculatedAmount = $seciliPaket->urun_fiyat + $kargoUcreti;
    $frontendAmount = floatval($data['amount'] ?? 0);
    
    if (abs($calculatedAmount - $frontendAmount) > 0.01) {
        error_log("Amount mismatch: Backend={$calculatedAmount}, Frontend={$frontendAmount}");
        // Use backend calculation for security
        $finalAmount = $calculatedAmount;
    } else {
        $finalAmount = $calculatedAmount;
    }
    
    // Clean phone number
    $phoneLength = strlen($data["telefon"]);
    if ($data["telefon"][0] == "0") {
        $data["telefon"] = substr($data["telefon"], 1, $phoneLength);
    }
    $cleanPhone = str_replace(["(", ")", "0090", "+90", " "], ["", "", "", "", ""], $data["telefon"]);

    // Check for duplicate orders (same as original logic)
    $onDkOnce = time() - 600;
    $kontrolSorgu = "SELECT * FROM siparisler WHERE sp_telefon = :telefon AND sp_tarih >= :zaman 
                     OR sp_musteri_ip = :ip AND sp_tarih >= :zaman";
    $kontrol = $db->db->prepare($kontrolSorgu);
    $kontrol->execute([
        'telefon' => $cleanPhone,
        'ip' => getIP(),
        'zaman' => $onDkOnce
    ]);
    
    if ($kontrol->fetch()) {
        echo json_encode(['success' => true, 'message' => 'Sipariş zaten mevcut']);
        exit;
    }

    // Process payment based on method
    $paymentResult = processPayment($data, $seciliPaket, $finalAmount);
    
    if (!$paymentResult['success']) {
        throw new Exception($paymentResult['message']);
    }

    // Prepare order data (keeping original structure)
    $insertSiparis = [
        "sp_site" => $site["site_id"],
        "sp_kaynak" => getAgent(),
        "sp_musteri" => $data["musteri"],
        "sp_telefon" => $cleanPhone,
        "sp_adres" => $data["adres"],
        "sp_siparis_tutari" => $seciliPaket->urun_fiyat,
        "sp_kargo_ucreti" => $kargoUcreti,
        "sp_odeme_yontemi" => $data["odeme_tipi"], // Original payment type for backend
        "sp_siparis_durumu" => ($data['payment_method'] === 'bank_transfer') ? 0 : 1, // 0 for pending, 1 for confirmed
        "sp_incelenme" => 0,
        "sp_musteri_ip" => getIP(),
        "sp_musteri_cihaz" => $_SERVER["HTTP_USER_AGENT"],
        "sp_tarih" => time(),
        "sp_payment_method" => $data['payment_method'], // New field for tracking actual payment method
        "sp_payment_status" => $paymentResult['payment_status'],
        "sp_payment_reference" => $paymentResult['payment_reference'] ?? null
    ];

    // Insert order
    $insertedSiparis = $db->ekle("siparisler", $insertSiparis);
    if (!$insertedSiparis) {
        throw new Exception("Sipariş kaydedilemedi");
    }
    
    $insertedSiparisID = $db->sonEklenen();

    // Insert order products (keeping original structure)
    $insertSipUrun = [
        "su_siparis_id" => $insertedSiparisID,
        "su_urun_id" => $urun["urun_id"],
        "su_adet" => $seciliPaket->urun_adet,
        "su_birim_id" => (!empty($seciliPaket->urun_birim)) ? $seciliPaket->urun_birim : 1,
        "su_fiyat" => $seciliPaket->urun_fiyat,
        "su_varyasyonlar" => isset($data["varyasyon"]) ? json_encode($data["varyasyon"], JSON_UNESCAPED_UNICODE) : "",
        "su_tarih" => time(),
        "su_durum" => 1
    ];

    $insertedSipUrun = $db->ekle("siparisler_urunler", $insertSipUrun);
    if (!$insertedSipUrun) {
        throw new Exception("Sipariş ürünleri kaydedilemedi");
    }

    // Return success response
    echo json_encode([
        'success' => true, 
        'message' => 'Sipariş başarıyla oluşturuldu',
        'order_id' => $insertedSiparisID,
        'payment_status' => $paymentResult['payment_status'],
        'requires_action' => $paymentResult['requires_action'] ?? false,
        'payment_intent_client_secret' => $paymentResult['client_secret'] ?? null
    ]);

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function processPayment($data, $seciliPaket, $finalAmount) {
    switch ($data['payment_method']) {
        case 'stripe':
            return processStripePayment($data, $seciliPaket, $finalAmount);
        case 'paypal':
            return processPayPalPayment($data, $seciliPaket, $finalAmount);
        case 'bank_transfer':
            return processBankTransfer($data, $seciliPaket, $finalAmount);
        default:
            throw new Exception('Geçersiz ödeme yöntemi');
    }
}

function processStripePayment($data, $seciliPaket, $finalAmount) {
    if (empty($data['stripe_token'])) {
        throw new Exception('Stripe token bulunamadı');
    }

    // Initialize Stripe (you need to install Stripe PHP library)
    // composer require stripe/stripe-php
    try {
        require_once 'vendor/autoload.php'; // If using Composer
        
        // Set your secret key
        \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

        $amount = $finalAmount * 100; // Stripe expects cents

        // Create charge
        $charge = \Stripe\Charge::create([
            'amount' => $amount,
            'currency' => 'eur',
            'source' => $data['stripe_token'],
            'description' => 'Sipariş: ' . $data['musteri'],
            'metadata' => [
                'customer_name' => $data['musteri'],
                'customer_phone' => $data['telefon'],
                'product_id' => $data['product_id']
            ]
        ]);

        if ($charge->status === 'succeeded') {
            return [
                'success' => true,
                'payment_status' => 'completed',
                'payment_reference' => $charge->id,
                'charge_id' => $charge->id
            ];
        } else {
            throw new Exception('Ödeme işlemi başarısız: ' . $charge->status);
        }

    } catch (\Stripe\Exception\CardException $e) {
        throw new Exception('Kart hatası: ' . $e->getError()->message);
    } catch (\Stripe\Exception\RateLimitException $e) {
        throw new Exception('Çok fazla istek, lütfen bekleyin');
    } catch (\Stripe\Exception\InvalidRequestException $e) {
        throw new Exception('Geçersiz istek');
    } catch (\Stripe\Exception\AuthenticationException $e) {
        throw new Exception('Stripe kimlik doğrulama hatası');
    } catch (\Stripe\Exception\ApiConnectionException $e) {
        throw new Exception('Stripe bağlantı hatası');
    } catch (\Stripe\Exception\ApiErrorException $e) {
        throw new Exception('Stripe API hatası');
    } catch (Exception $e) {
        throw new Exception('Ödeme hatası: ' . $e->getMessage());
    }
}

function processPayPalPayment($data, $seciliPaket, $finalAmount) {
    if (empty($data['paypal_order_id']) || empty($data['paypal_payment_id'])) {
        throw new Exception('PayPal ödeme bilgileri eksik');
    }

    // Here you would verify the PayPal payment with their API
    // For now, we'll assume it's successful since PayPal handles the verification on frontend
    
    return [
        'success' => true,
        'payment_status' => 'completed',
        'payment_reference' => $data['paypal_payment_id'],
        'paypal_order_id' => $data['paypal_order_id'],
        'amount' => $finalAmount
    ];
}

function processBankTransfer($data, $seciliPaket, $finalAmount) {
    // Bank transfer requires manual verification
    return [
        'success' => true,
        'payment_status' => 'pending',
        'payment_reference' => 'BANK_' . time(),
        'requires_manual_verification' => true,
        'amount' => $finalAmount
    ];
}

// Add these functions if they don't exist in userAgent.php
if (!function_exists('getAgent')) {
    function getAgent() {
        return $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    }
}

function getIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}
?> 