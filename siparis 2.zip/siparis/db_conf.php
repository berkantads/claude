<?php

/***
 * BPANEL v1.0 -
 * Geliştiren: www.baranmy.com
 */

define('db_host', 'localhost');
define('db_name', 'bpanelc_bpanel');
define('db_username', 'bpanelc_bpanel');
define('db_password', '4~c?a+{A*w9v');
?>