<?php

error_reporting(E_ALL);
ini_set("display_errors", 1);

require "ayarlar.php";
require "classes/userAgent.php";
if (!$_POST["paket"] && !$_POST["product_id"]) {
} else {
    $seciliPaket = $paketler[$_POST["paket"]];
    $kargoUcreti = ($seciliPaket->ucretsiz_kargo == 1) ? 0 : $seciliPaket->kargo_tutari;
    $phoneLength = strlen($_POST["telefon"]);
    if ($_POST["telefon"][0] == "0")
        $_POST["telefon"] = substr($_POST["telefon"], 1, $phoneLength);
    $insertSiparis["sp_site"] = $site["site_id"];
    $insertSiparis["sp_kaynak"] = getAgent();
    $insertSiparis["sp_musteri"] = $_POST["musteri"];
    $insertSiparis["sp_telefon"] = str_replace(["(", ")", "0090", "+90", " "], ["", "", "", "", ""], $_POST["telefon"]);
    $insertSiparis["sp_sehir"] = $_POST["sehir"];
    $insertSiparis["sp_ilce"] = $_POST["ilce"];
    $insertSiparis["sp_adres"] = $_POST["adres"];
    $insertSiparis["sp_siparis_tutari"] = $seciliPaket->urun_fiyat;
    $insertSiparis["sp_kargo_ucreti"] = $kargoUcreti;
    $insertSiparis["sp_odeme_yontemi"] = $_POST["odeme_tipi"];
    $insertSiparis["sp_siparis_durumu"] = 1;
    $insertSiparis["sp_incelenme"] = 0;
    $insertSiparis["sp_musteri_ip"] = getIP();
    $insertSiparis["sp_musteri_cihaz"] = $_SERVER["HTTP_USER_AGENT"];
    $insertSiparis["sp_tarih"] = time();

    if ($insertSiparis) {
        $gun = 1 * 60 * 60 * 24 * 7;
        $onDkOnce = time() - 600;
        $kontrol = $db->sorguGetir("select * from siparisler where sp_telefon = '{$insertSiparis["sp_telefon"]}' and sp_tarih >= '{$onDkOnce}' || sp_musteri_ip = '{$insertSiparis["sp_musteri_ip"]}' and sp_tarih >= '{$onDkOnce}'");
        if ($kontrol) {
            require "siparis_tamamlandi.php";
            exit();
        }
        $insertedSiparis = $db->ekle("siparisler", $insertSiparis);
        if ($insertedSiparis)
            $insertedSiparisID = $db->sonEklenen();
        if ($insertedSiparisID) {
            $insertSipUrun["su_siparis_id"] = $insertedSiparisID;
            $insertSipUrun["su_urun_id"] = $urun["urun_id"];
            $insertSipUrun["su_adet"] = $seciliPaket->urun_adet;
            $insertSipUrun["su_birim_id"] = (!empty($seciliPaket->urun_birim)) ? $seciliPaket->urun_birim : 1;
            $insertSipUrun["su_fiyat"] = $seciliPaket->urun_fiyat;
            $insertSipUrun["su_varyasyonlar"] = ($varyasyonlar) ? json_encode($_POST["varyasyon"], JSON_UNESCAPED_UNICODE) : "";
            $insertSipUrun["su_tarih"] = time();
            $insertSipUrun["su_durum"] = 1;

            if ($insertSipUrun)
                $insertedSipUrun = $db->ekle("siparisler_urunler", $insertSipUrun);
            if ($insertSipUrun)
                $insertedSipUrunID = $db->sonEklenen();

            if ($insertedSiparisID && $insertedSipUrunID) {
                if (empty($site["site_sonuc_sayfasi"]))
                    require "siparis_tamamlandi.php";
                else
                    header("Location: " . $site["site_sonuc_sayfasi"]);
            }
        }
    }
}
?>
