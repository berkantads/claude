<!DOCTYPE html>
<html>
<head>
<script>(function(E,n,G,A,g,Y,a){E['EngLandingObject']=g;E[g]=E[g]||function(){ (E[g].q=E[g].q||[]).push(arguments)},E[g].l=1*new Date();Y=n.createElement(G), a=n.getElementsByTagName(G)[0];Y.async=1;Y.src=A;a.parentNode.insertBefore(Y,a)})(window,document,'script','//widget.engageya.com/eng_landing.js','__engLanding');__engLanding('createPixel',{pixelid:210702,dtms:0});</script>
<!-- TikTok Pixel Code Start -->
<script>
!function (w, d, t) {
  w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie","holdConsent","revokeConsent","grantConsent"],ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){for(
var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e},ttq.load=function(e,n){var r="https://analytics.tiktok.com/i18n/pixel/events.js",o=n&&n.partner;ttq._i=ttq._i||{},ttq._i[e]=[],ttq._i[e]._u=r,ttq._t=ttq._t||{},ttq._t[e]=+new Date,ttq._o=ttq._o||{},ttq._o[e]=n||{};n=document.createElement("script")
;n.type="text/javascript",n.async=!0,n.src=r+"?sdkid="+e+"&lib="+t;e=document.getElementsByTagName("script")[0];e.parentNode.insertBefore(n,e)};


  ttq.load('D1V0QEBC77U2447SGRJ0');
  ttq.page();
}(window, document, 'ttq');
</script>
<!-- TikTok Pixel Code End -->
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '751434259335850');
fbq('track', 'Purchase');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=751434259335850&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
    <title>Sipariş Oluşturuldu</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <?php
    if ($site["site_fb_piksel"]):
        ?>
        <!-- Facebook Pixel Code -->
        <script>
            !function (f, b, e, v, n, t, s) {
                if (f.fbq) return;
                n = f.fbq = function () {
                    n.callMethod ?
                        n.callMethod.apply(n, arguments) : n.queue.push(arguments)
                };
                if (!f._fbq) f._fbq = n;
                n.push = n;
                n.loaded = !0;
                n.version = '2.0';
                n.queue = [];
                t = b.createElement(e);
                t.async = !0;
                t.src = v;
                s = b.getElementsByTagName(e)[0];
                s.parentNode.insertBefore(t, s)
            }(window, document, 'script',
                'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', '<?=$site["site_fb_piksel"];?>');
            fbq('track', 'Purchase', {
                value: '<?=$insertSiparis["sp_siparis_tutari"];?>',
                currency: 'TRY'
            });
            fbq('track', 'PageView');
        </script>
        <noscript>
            <img height="1" width="1"
                 src="https://www.facebook.com/tr?id=<?= $site["site_fb_piksel"]; ?>&ev=PageView&noscript=1"/>
        </noscript>
        <!-- End Facebook Pixel Code -->
    <?php
    endif;
    ?>
    <?php
    if (!empty($site["site_gg_donusum"])):
        $ggDonusum = explode("/", $site["site_gg_donusum"]);
        ?>
        <!-- Google Dönüşüm Kodu -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=AW-CONVERSION_ID"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }

            gtag('js', new Date());
            gtag('config', '<?=$ggDonusum[0];?>');
        </script>
        <script>
            gtag('event', 'conversion', {
                'send_to': '<?=$ggDonusum[0];?>/<?=$ggDonusum[1];?>',
                'value': <?=$insertSiparis["sp_siparis_tutari"] + $insertSiparis["sp_kargo_tutari"];?>,
                'currency': 'TRY'
            });
        </script>
        <!-- Google Dönüşüm Kodu -->


    <?php
    endif;
    ?>
</head>
<style>
    @media screen {
        .cerceve {
            position: relative;
            bottom: 20% !important;
        }

        .cerceve > img {
            width: 100%;
        }
    }
</style>
<body>
<div class="container">
    <div class="row text-center">
        <div class="col-sm-6 col-sm-offset-3">
            <br><br>
            <h2 style="color:#0fad00">Siparişiniz Oluşturuldu</h2>
            <img src="/siparis/assets/img/check.png" width="150px">
            <h3>Sayın, <?= $insertSiparis["sp_musteri"]; ?></h3>
            <p style="font-size:20px;color:#5C5C5C;">
                Siparişiniz tarafımıza ulaşmıştır.<br/>En kısa sürede müşteri temsilcilerimiz tarafından iletişime geçilecektir.Ya da Whatsapp Üzerinden Onay Mesajı Alacaksınız. Bizi tercih ettiğiniz için teşekkür eder şifalı günler dileriz.
            </p>
            <br><br>
        </div>

    </div>
</div>
<!-- Mgid Sensor -->
 <script type="text/javascript"> (function() { var d = document, w = window; w.MgSensorData = w.MgSensorData || []; w.MgSensorData.push({ cid:618379, lng:"us", project: "a.mgid.com" }); var l = "a.mgid.com"; var n = d.getElementsByTagName("script")[0]; var s = d.createElement("script"); s.type = "text/javascript"; s.async = true; var dt = !Date.now?new Date().valueOf():Date.now(); s.src = "https://" + l + "/mgsensor.js?d=" + dt; n.parentNode.insertBefore(s, n); })();
 </script>
 <!-- /Mgid Sensor -->

</body>
</html>
