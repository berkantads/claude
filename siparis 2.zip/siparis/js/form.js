$("select[name='sehir']").change(function () {
    var sehir = $(this).val();
    var url = "ajax.php";
    $.post(url, {sehir}).done(function (data) {
        $("select[name='ilce']").html(data);
    });
});