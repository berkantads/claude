// Payment Module JavaScript
class PaymentModule {
    constructor() {
        this.config = null;
        this.stripe = null;
        this.stripeElements = null;
        this.cardNumber = null;
        this.cardExpiry = null;
        this.cardCvc = null;
        this.stripeLoaded = false;
    }
    
    async init() {
        try {
            await this.loadConfig();
            this.setupPaymentMethodToggle();
            this.loadStripe();
            this.loadPayPal();
            this.setupFormSubmission();
            this.setupMobileOptimizations();
            console.log('Payment module initialized successfully');
        } catch (error) {
            console.error('Payment module initialization failed:', error);
            this.showError('Ödeme sistemi yüklenirken hata oluştu. Lütfen sayfayı yenileyin.');
        }
    }
    
    async loadConfig() {
        try {
            const response = await fetch('get_payment_config.php');
            if (!response.ok) {
                throw new Error('Config yüklenemedi');
            }
            this.config = await response.json();
        } catch (error) {
            console.error('Config load error:', error);
            // Fallback config for development
            this.config = {
                stripe: {
                    publishable_key: 'pk_live_51NNYo1BYyd0bfLOIUiNOq6OypoBFtZ3psabQmK0HXdsPk4A9sF2MQrUOslV20QaBoyxg9ol4gJjPgutWzW4cDpR000ARLIVECY',
                    currency: 'EUR'
                },
                paypal: {
                    client_id: 'Ad0AlQAECvDlYgVY6XmNLwX2A-cYV6Dl8VQaopDIeOxPoA_Z_k5IwMNMcGp2jht-CUaDLYFl62jo0IGW',
                    environment: 'production',
                    currency: 'EUR'
                },
                general: {
                    currency: 'EUR'
                }
            };
        }
    }
    
    setupPaymentMethodToggle() {
        const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
        
        paymentRadios.forEach(radio => {
            radio.addEventListener('change', () => {
                this.togglePaymentDetails(radio.value);
            });
        });
        
        // Initialize with default selection
        const checkedRadio = document.querySelector('input[name="payment_method"]:checked');
        if (checkedRadio) {
            this.togglePaymentDetails(checkedRadio.value);
        }
        
        // Listen for package changes to update prices
        this.setupPackageListener();
    }
    
    setupPackageListener() {
        const packageRadios = document.querySelectorAll('input[name="paket"]');
        
        packageRadios.forEach(radio => {
            radio.addEventListener('change', () => {
                this.updatePaymentAmounts();
                this.reloadPayPal();
            });
        });
        
        // Initial price update
        this.updatePaymentAmounts();
    }
    
    updatePaymentAmounts() {
        const packageInfo = this.getSelectedPackageInfo();
        if (!packageInfo) return;
        
        // Update payment display amounts
        const amountDisplays = document.querySelectorAll('.payment-amount-display');
        amountDisplays.forEach(display => {
            display.textContent = `${packageInfo.total.toFixed(2)} €`;
        });
        
        // Update PayPal display
        const paypalInfo = document.querySelector('.paypal-info p');
        if (paypalInfo) {
            paypalInfo.innerHTML = `PayPal hesabınız veya kredi kartınız ile güvenle ödeme yapabilirsiniz.<br>
                                   <strong>Ödenecek Tutar: ${packageInfo.total.toFixed(2)} €</strong>`;
        }
        
        console.log('Updated payment amount:', packageInfo);
    }
    
    reloadPayPal() {
        // Clear existing PayPal buttons
        const container = document.getElementById('paypal-button-container');
        if (container) {
            container.innerHTML = '';
        }
        
        // Reload PayPal with new amount
        setTimeout(() => {
            if (typeof paypal !== 'undefined') {
                this.initPayPal();
            }
        }, 100);
    }
    
    togglePaymentDetails(selectedMethod) {
        // Hide all payment details
        document.querySelectorAll('.payment-details').forEach(detail => {
            detail.style.display = 'none';
            detail.classList.remove('show');
        });
        
        // Show selected payment details
        const selectedDetails = document.getElementById(`${selectedMethod}_details`);
        if (selectedDetails) {
            selectedDetails.style.display = 'block';
            setTimeout(() => {
                selectedDetails.classList.add('show');
            }, 50);
        }
        
        // Initialize Stripe elements when Stripe payment is selected
        if (selectedMethod === 'stripe' && !this.stripeLoaded) {
            setTimeout(() => {
                this.initStripeElements();
            }, 100);
        }
        
        // Update payment option styling
        document.querySelectorAll('.payment-option').forEach(option => {
            option.classList.remove('selected');
        });
        
        const selectedOption = document.querySelector(`#${selectedMethod}_payment`).closest('.payment-option');
        if (selectedOption) {
            selectedOption.classList.add('selected');
        }
    }
    
    async loadStripe() {
        try {
            if (typeof Stripe === 'undefined') {
                const script = document.createElement('script');
                script.src = 'https://js.stripe.com/v3/';
                script.onload = () => {
                    console.log('Stripe script loaded');
                    this.stripe = Stripe(this.config.stripe.publishable_key);
                    this.stripeElements = this.stripe.elements();
                };
                script.onerror = () => {
                    console.error('Failed to load Stripe script');
                };
                document.head.appendChild(script);
            } else {
                this.stripe = Stripe(this.config.stripe.publishable_key);
                this.stripeElements = this.stripe.elements();
            }
        } catch (error) {
            console.error('Stripe loading error:', error);
        }
    }
    
    initStripeElements() {
        if (!this.stripe || !this.stripeElements || this.stripeLoaded) {
            console.log('Stripe not ready or already loaded');
            return;
        }
        
        try {
            // Check if containers exist
            const cardNumberContainer = document.getElementById('stripe-card-number');
            const cardExpiryContainer = document.getElementById('stripe-card-expiry');
            const cardCvcContainer = document.getElementById('stripe-card-cvc');
            
            if (!cardNumberContainer || !cardExpiryContainer || !cardCvcContainer) {
                console.error('Stripe containers not found');
                return;
            }
            
            // Show loading state
            const loadingDiv = document.getElementById('stripe-loading');
            const elementsDiv = document.getElementById('stripe-elements');
            
            if (loadingDiv) loadingDiv.style.display = 'block';
            if (elementsDiv) elementsDiv.style.display = 'none';
            
            // Create card elements with mobile-friendly styling
            const style = {
                base: {
                    fontSize: '16px',
                    color: '#424770',
                    fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                    fontSmoothing: 'antialiased',
                    '::placeholder': {
                        color: '#aab7c4',
                    },
                },
                invalid: {
                    color: '#9e2146',
                },
            };
            
            // Clear existing elements if any
            if (this.cardNumber) {
                this.cardNumber.unmount();
                this.cardNumber.destroy();
            }
            if (this.cardExpiry) {
                this.cardExpiry.unmount();
                this.cardExpiry.destroy();
            }
            if (this.cardCvc) {
                this.cardCvc.unmount();
                this.cardCvc.destroy();
            }
            
            this.cardNumber = this.stripeElements.create('cardNumber', { 
                style,
                placeholder: '1234 1234 1234 1234'
            });
            this.cardExpiry = this.stripeElements.create('cardExpiry', { style });
            this.cardCvc = this.stripeElements.create('cardCvc', { style });
            
            // Mount elements
            this.cardNumber.mount('#stripe-card-number');
            this.cardExpiry.mount('#stripe-card-expiry');
            this.cardCvc.mount('#stripe-card-cvc');
            
            // Handle real-time validation errors
            this.cardNumber.on('change', this.handleStripeError.bind(this));
            this.cardExpiry.on('change', this.handleStripeError.bind(this));
            this.cardCvc.on('change', this.handleStripeError.bind(this));
            
            // Hide loading and show elements
            setTimeout(() => {
                if (loadingDiv) loadingDiv.style.display = 'none';
                if (elementsDiv) elementsDiv.style.display = 'block';
            }, 500);
            
            this.stripeLoaded = true;
            console.log('Stripe elements initialized successfully');
            
        } catch (error) {
            console.error('Stripe elements initialization error:', error);
            // Hide loading on error
            const loadingDiv = document.getElementById('stripe-loading');
            if (loadingDiv) {
                loadingDiv.innerHTML = '<div class="text-danger">Kredi kartı alanları yüklenemedi. Lütfen sayfayı yenileyin.</div>';
            }
        }
    }
    
    handleStripeError(event) {
        const errorElement = document.getElementById('stripe-card-errors');
        if (errorElement) {
            if (event.error) {
                errorElement.textContent = event.error.message;
                errorElement.style.display = 'block';
            } else {
                errorElement.style.display = 'none';
            }
        }
    }
    
    loadPayPal() {
        if (typeof paypal !== 'undefined') {
            this.initPayPal();
            return;
        }
        
        const script = document.createElement('script');
        script.src = `https://www.paypal.com/sdk/js?client-id=${this.config.paypal.client_id}&currency=${this.config.paypal.currency}`;
        script.onload = () => {
            this.initPayPal();
        };
        document.head.appendChild(script);
    }
    
    initPayPal() {
        if (typeof paypal === 'undefined') return;
        
        const container = document.getElementById('paypal-button-container');
        if (!container) return;
        
        paypal.Buttons({
            createOrder: (data, actions) => {
                const amount = this.calculateOrderAmount();
                const packageInfo = this.getSelectedPackageInfo();
                
                if (amount <= 0) {
                    throw new Error('Lütfen bir paket seçin');
                }
                
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: amount.toFixed(2),
                            currency_code: this.config.paypal.currency
                        },
                        description: packageInfo ? packageInfo.title : 'Sipariş'
                    }]
                });
            },
            
            onApprove: async (data, actions) => {
                try {
                    const order = await actions.order.capture();
                    await this.handlePayPalSuccess(order);
                } catch (error) {
                    console.error('PayPal payment failed:', error);
                    this.showError('PayPal ödemesi tamamlanamadı. Lütfen tekrar deneyin.');
                }
            },
            
            onError: (err) => {
                console.error('PayPal error:', err);
                this.showError('PayPal hatası. Lütfen tekrar deneyin.');
            },
            
            style: {
                layout: 'vertical',
                color: 'blue',
                shape: 'rect',
                label: 'paypal',
                height: 45
            }
        }).render('#paypal-button-container');
    }
    
    async handlePayPalSuccess(order) {
        const orderData = this.getOrderData();
        orderData.payment_method = 'paypal';
        orderData.paypal_order_id = order.id;
        orderData.paypal_payment_id = order.purchase_units[0].payments.captures[0].id;
        orderData.amount = this.calculateOrderAmount();
        
        const response = await this.submitOrder(orderData);
        
        if (response.success) {
            this.redirectToSuccess();
        } else {
            throw new Error(response.message || 'Sipariş kaydedilemedi');
        }
    }
    
    setupFormSubmission() {
        const form = document.getElementById('siparisformu');
        const submitButton = document.getElementById('button');
        
        if (form && submitButton) {
            submitButton.addEventListener('click', async (e) => {
                e.preventDefault();
                await this.handleFormSubmit();
            });
        }
    }
    
    async handleFormSubmit() {
        // Validate form fields first
        if (!this.validateForm()) {
            return;
        }
        
        const selectedPaymentMethod = document.querySelector('input[name="payment_method"]:checked')?.value;
        
        if (!selectedPaymentMethod) {
            this.showError('Lütfen bir ödeme yöntemi seçin.');
            return;
        }
        
        this.showLoading(true);
        
        try {
            switch (selectedPaymentMethod) {
                case 'stripe':
                    await this.processStripePayment();
                    break;
                case 'paypal':
                    this.showError('PayPal butonunu kullanarak ödeme yapın.');
                    break;
                case 'bank_transfer':
                    await this.processBankTransfer();
                    break;
                default:
                    throw new Error('Geçersiz ödeme yöntemi');
            }
        } catch (error) {
            this.showError(error.message);
        } finally {
            this.showLoading(false);
        }
    }
    
    async processStripePayment() {
        // Check if Stripe elements are properly loaded
        if (!this.cardNumber || !this.cardExpiry || !this.cardCvc) {
            this.showError('Kredi kartı alanları yüklenirken hata oluştu. Lütfen sayfayı yenileyin.');
            return;
        }
        
        const cardholderName = document.getElementById('stripe-cardholder-name').value;
        
        if (!cardholderName.trim()) {
            throw new Error('Kart üzerindeki ismi giriniz.');
        }
        
        const amount = this.calculateOrderAmount();
        const packageInfo = this.getSelectedPackageInfo();
        
        if (amount <= 0) {
            throw new Error('Lütfen bir paket seçin');
        }
        
        try {
            const { token, error } = await this.stripe.createToken(this.cardNumber, {
                name: cardholderName
            });
            
            if (error) {
                throw new Error(error.message);
            }
            
            const orderData = this.getOrderData();
            orderData.payment_method = 'stripe';
            orderData.stripe_token = token.id;
            orderData.amount = amount;
            orderData.package_info = packageInfo;
            
            const response = await this.submitOrder(orderData);
            
            if (response.success) {
                if (response.requires_action) {
                    await this.handleStripeAction(response.payment_intent_client_secret);
                } else {
                    this.redirectToSuccess();
                }
            } else {
                throw new Error(response.message || 'Ödeme işlemi başarısız');
            }
        } catch (error) {
            throw new Error(error.message || 'Kredi kartı işleminde hata oluştu');
        }
    }
    
    async handleStripeAction(clientSecret) {
        const { error } = await this.stripe.confirmCardPayment(clientSecret);
        
        if (error) {
            throw new Error(error.message);
        } else {
            this.redirectToSuccess();
        }
    }
    
    async processBankTransfer() {
        const orderData = this.getOrderData();
        orderData.payment_method = 'bank_transfer';
        orderData.amount = this.calculateOrderAmount();
        
        const response = await this.submitOrder(orderData);
        
        if (response.success) {
            this.redirectToSuccess();
        } else {
            throw new Error(response.message || 'Sipariş kaydedilemedi');
        }
    }
    
    getOrderData() {
        const form = document.getElementById('siparisformu');
        const formData = new FormData(form);
        
        return {
            product_id: formData.get('product_id'),
            paket: formData.get('paket'),
            musteri: formData.get('musteri'),
            telefon: formData.get('telefon'),
            adres: formData.get('adres'),
            varyasyon: this.getVariations()
        };
    }
    
    getVariations() {
        const variations = {};
        const selects = document.querySelectorAll('select[name^="varyasyon"]');
        
        selects.forEach(select => {
            if (select.value) {
                const name = select.name.replace('varyasyon[', '').replace('][]', '');
                if (!variations[name]) {
                    variations[name] = [];
                }
                variations[name].push(select.value);
            }
        });
        
        return variations;
    }
    
    async submitOrder(orderData) {
        const response = await fetch('process_payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(orderData)
        });
        
        return await response.json();
    }
    
    calculateOrderAmount() {
        const selectedPackage = document.querySelector('input[name="paket"]:checked');
        if (!selectedPackage) return 0;
     
        const price = parseFloat(selectedPackage.dataset.price || 0);
        const cargo = parseFloat(selectedPackage.dataset.cargo || 0);
        
        return price + cargo;
    }
    
    getSelectedPackageInfo() {
        const selectedPackage = document.querySelector('input[name="paket"]:checked');
        if (!selectedPackage) return null;
        
        return {
            index: selectedPackage.value,
            price: parseFloat(selectedPackage.dataset.price || 0),
            cargo: parseFloat(selectedPackage.dataset.cargo || 0),
            title: selectedPackage.dataset.title || '',
            total: parseFloat(selectedPackage.dataset.price || 0) + parseFloat(selectedPackage.dataset.cargo || 0)
        };
    }
    
    validateForm() {
        const requiredFields = [
            { field: 'musteri', message: 'Ad soyad gerekli' },
            { field: 'telefon', message: 'Telefon numarası gerekli' },
            { field: 'adres', message: 'Adres gerekli' }
        ];
        
        for (let { field, message } of requiredFields) {
            const input = document.querySelector(`[name="${field}"]`);
            if (!input || !input.value.trim()) {
                this.showError(message);
                if (input) input.focus();
                return false;
            }
        }
        
        // Check if package is selected
        const selectedPackage = document.querySelector('input[name="paket"]:checked');
        if (!selectedPackage) {
            this.showError('Lütfen bir paket seçin');
            return false;
        }
        
        return true;
    }
    
    setupMobileOptimizations() {
        // Touch event handling for mobile
        if ('ontouchstart' in window) {
            const paymentLabels = document.querySelectorAll('.payment-label');
            paymentLabels.forEach(label => {
                label.addEventListener('touchstart', function() {
                    this.style.backgroundColor = '#f8f9fa';
                });
                
                label.addEventListener('touchend', function() {
                    setTimeout(() => {
                        this.style.backgroundColor = '';
                    }, 150);
                });
            });
        }
        
        // Prevent zoom on input focus (iOS)
        const inputs = document.querySelectorAll('input[type="text"], input[type="tel"], input[type="email"], textarea');
        inputs.forEach(input => {
            if (input.getAttribute('data-zoom-disabled') !== 'true') {
                input.style.fontSize = '16px';
                input.setAttribute('data-zoom-disabled', 'true');
            }
        });
        
        // Optimize viewport for mobile payments
        const viewport = document.querySelector('meta[name="viewport"]');
        if (viewport && window.innerWidth <= 768) {
            viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
        }
    }
    
    showError(message) {
        // Simple alert for now - can be enhanced with custom modal
        alert(message);
        console.error(message);
    }
    
    showLoading(show) {
        const button = document.getElementById('button');
        const paymentModule = document.querySelector('.payment-module');
        
        if (show) {
            if (button) {
                button.disabled = true;
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> İşleniyor...';
            }
            if (paymentModule) {
                paymentModule.classList.add('payment-loading');
            }
        } else {
            if (button) {
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-check-circle"></i> Siparişimi Tamamla';
            }
            if (paymentModule) {
                paymentModule.classList.remove('payment-loading');
            }
        }
    }
    
    redirectToSuccess() {
        window.location.href = 'siparis_tamamlandi.php';
    }
}

// Initialize payment module when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    const paymentModule = new PaymentModule();
    paymentModule.init().catch(error => {
        console.error('Payment module failed to initialize:', error);
    });
});

// Export for external use if needed
window.PaymentModule = PaymentModule; 