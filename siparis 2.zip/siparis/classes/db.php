<?php

class DB
{

    public $db;

    public function __construct()
    {
        $host = db_host;
        $user = db_username;
        $database = db_name;
        $password = db_password;
        try {
            $this->db = new PDO("mysql:host=" . $host . ";dbname=" . $database . ";charset=utf8", $user, $password);
        } catch (PDOException $e) {
            print_r($e);
        }
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
    }

    public static function baglan()
    {
        $db = new PDO("mysql:host=" . db_host . ";dbname=" . db_name . ";", db_username, db_password);
        return $db;
    }

    public function getirTek($tablo, $where = null)
    {
        $query = "select * from " . $tablo;
        if ($where) {
            $query .= " where ";
            $param = 0;
            foreach ($where as $key => $value) {
                $value = htmlentities($value,ENT_QUOTES,"UTF-8");
				$entities = ["&quot;","&Ccedil;","&ouml;","&uuml;","&ccedil;","&Ouml;","&Uuml;","&ugrave;","&Ugrave;","&acirc;","&Acirc;",
							 "&#039;","&Igrave;","&igrave;","&Otilde;","&otilde;","&Iacute;","&iacute;","&Icirc;","&icirc;","&mdash;","&Iuml;","&iuml;"
							 ];
				$tr = ["\"","Ç","ö","ü","ç","Ö","Ü","ù","Ù","â","Â","","Ì","ì","Õ","õ","Í","í","Î","î","-","Ï","ï"];
				$value = str_replace($entities,$tr,$value);
                $param++;
                $query .= " {$key} = '{$value}'";
                if (count($where) > $param) {
                    $query .= " and ";
                }
            }
        }
        return $this->db->query($query)->fetch();
    }

    public function getir($tablo, $where = null, $order = '', $limit = null)
    {
        $query = "select * from " . $tablo;
        if ($where && count($where)) {
            $query .= " where ";
            $param = 0;
            foreach ($where as $key => $value) {
                $value = htmlentities($value,ENT_QUOTES,"UTF-8");
				$entities = ["&quot;","&Ccedil;","&ouml;","&uuml;","&ccedil;","&Ouml;","&Uuml;","&ugrave;","&Ugrave;","&acirc;","&Acirc;",
							 "&#039;","&Igrave;","&igrave;","&Otilde;","&otilde;","&Iacute;","&iacute;","&Icirc;","&icirc;","&mdash;","&Iuml;","&iuml;"
							 ];
				$tr = ["\"","Ç","ö","ü","ç","Ö","Ü","ù","Ù","â","Â","","Ì","ì","Õ","õ","Í","í","Î","î","-","Ï","ï"];
				$value = str_replace($entities,$tr,$value);
                $param++;
                $query .= " {$key} = '{$value}'";
                if (count($where) > $param) {
                    $query .= " and ";
                }
            }
        }
        if ($limit) {
            $query .= " limit " . $limit;
        }

        if ($order) {
            $query .= " order by " . $order;
        }

        return $this->db->query($query)->fetchAll();
    }

    public function guncelle($tablo, $veri, $where)
    {
        $query = "update {$tablo} set ";
        $paramVeri = 0;
        foreach ($veri as $key => $value) {
            $value = htmlentities($value,ENT_QUOTES,"UTF-8");
            $entities = ["&quot;","&Ccedil;","&ouml;","&uuml;","&ccedil;","&Ouml;","&Uuml;","&ugrave;","&Ugrave;","&acirc;","&Acirc;",
							 "&#039;","&Igrave;","&igrave;","&Otilde;","&otilde;","&Iacute;","&iacute;","&Icirc;","&icirc;","&mdash;","&Iuml;","&iuml;"
							 ];
			$tr = ["\"","Ç","ö","ü","ç","Ö","Ü","ù","Ù","â","Â","","Ì","ì","Õ","õ","Í","í","Î","î","-","Ï","ï"];
            $value = str_replace($entities,$tr,$value);
            $paramVeri++;
            $query .= " {$key} = '{$value}'";
            if (count($veri) > $paramVeri) {
                $query .= ",";
            }
        }

        if ($where) {
            $veriler = array_merge($veri, $where);
            $query .= " where ";
            $paramWhere = 0;
            foreach ($where as $key => $value) {
                $value = htmlentities($value,ENT_QUOTES,"UTF-8");
            $entities = ["&quot;","&Ccedil;","&ouml;","&uuml;","&ccedil;","&Ouml;","&Uuml;","&ugrave;","&Ugrave;","&acirc;","&Acirc;",
							 "&#039;","&Igrave;","&igrave;","&Otilde;","&otilde;","&Iacute;","&iacute;","&Icirc;","&icirc;","&mdash;","&Iuml;","&iuml;"
							 ];
			$tr = ["\"","Ç","ö","ü","ç","Ö","Ü","ù","Ù","â","Â","","Ì","ì","Õ","õ","Í","í","Î","î","-","Ï","ï"];
            $value = str_replace($entities,$tr,$value);
                $paramWhere++;
                $query .= " {$key} = '{$value}'";
                if (count($where) > $paramWhere) {
                    $query .= " and ";
                }
            }
        } else {
            $veriler = $veri;
        }

        $update = $this->db->prepare($query)->execute($veriler);
        if ($update) {
            return true;
        } else {
            return false;
        }
    }

    public function ekle($tablo, $veri)
    {
        $query = "insert into {$tablo} set ";
        $paramVeri = 0;
        foreach ($veri as $key => $value) {
            $value = htmlentities($value,ENT_QUOTES,"UTF-8");
            $entities = ["&quot;","&Ccedil;","&ouml;","&uuml;","&ccedil;","&Ouml;","&Uuml;","&ugrave;","&Ugrave;","&acirc;","&Acirc;",
							 "&#039;","&Igrave;","&igrave;","&Otilde;","&otilde;","&Iacute;","&iacute;","&Icirc;","&icirc;","&mdash;","&Iuml;","&iuml;"
							 ];
			$tr = ["\"","Ç","ö","ü","ç","Ö","Ü","ù","Ù","â","Â","","Ì","ì","Õ","õ","Í","í","Î","î","-","Ï","ï"];
            $value = str_replace($entities,$tr,$value);
            $paramVeri++;
            $query .= " {$key} = '{$value}'";
            if (count($veri) > $paramVeri) {
                $query .= ",";
            }
        }

        $update = $this->db->prepare($query)->execute($veri);
        if ($update) {
            return true;
        } else {
            return false;
        }
    }

    public function sonEklenen($tableName = null)
    {
        return $this->db->lastInsertId($tableName);
    }

    public function sorguGetir($query)
    {
        return $this->db->query($query)->fetchAll();
    }
}