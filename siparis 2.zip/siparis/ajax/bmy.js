$('#city').change(function () {
    selectedCity = $(this).val();
    //alert(selectedCity);
    if (selectedCity) {
        $.post('resources/cities.php', {cityId: selectedCity}).done(function (data) {
            $('#district').html(data);
        })
    }
});

function tst() {
    var phoneSize = $('input[name="phone"]').val().length;
    if (phoneSize >= 10) {
        $.post('tstTamamla.php', $('form').serialize()).done(function (data) {
            //alert(data);
        });
    } else {
        //console.log('tst çalışmıyor...');
    }
}

// ödeme tipi kontrolü yapıyoruz
$('input[name="payment_type"]').change(function () {
    selectedPT = $(this).val();
});